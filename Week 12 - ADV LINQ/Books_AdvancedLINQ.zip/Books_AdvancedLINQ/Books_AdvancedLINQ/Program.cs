﻿/**
 * Sean Armbruster 
 * CSC 253
 * 
 * Advanced Linq program 
 * 
 * 1. Display title where pages are greater than 300 and category is 3 or 4 (greater than 2
 * 2. Display title of all books between 300 - 400 pages
 * 3. Display ISBN, title, author, pages of books order by ISBN
 * 4. Display ISBN, title, author, pages of books order by category ID and title
 * 5. Display groups and titles of different categories
 * 6. Use left outer join to group categories but with category descriptions
 * 7. Use inner join to display titles and categories
 * 
 **/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalProjectTemplate
{
    class Program
    {
        static void Main(string[] args)
        {

            List<Book> bookList = new List<Book>() {
            new Book() { ISBN = "90202101", Title = "Chamber of Secrets", Author = "Rowling", Pages = 328, CategoryID = 1 } ,
            new Book() { ISBN = "34812346", Title = "A Brief History of Time", Author = "Hawking", Pages = 310, CategoryID = 3 } ,
            new Book() { ISBN = "45634631", Title = "The Road Less Traveled", Author = "Peck", Pages = 175, CategoryID = 4 },
            new Book() { ISBN = "89101202", Title = "Where the Wild Things Are", Author = "Sendak", Pages = 333, CategoryID = 1 } ,
            new Book() { ISBN = "30203032", Title = "It", Author = "King", Pages = 390, CategoryID = 2 } ,
            new Book() { ISBN = "50235488", Title = "A Man on the Moon", Author = "Chaikin", Pages = 212, CategoryID = 3 } ,
            new Book() { ISBN = "87240402", Title = "Dracula", Author = "Stoker", Pages = 287, CategoryID = 2 } ,
            new Book() { ISBN = "58019199", Title = "The Four Agreements", Author = "Ruiz", Pages = 410, CategoryID = 4 }
            };

            List<Category> categoryList = new List<Category>() {
            new Category(){ CategoryID = 1, CategoryName="Children"},
            new Category(){ CategoryID = 2, CategoryName="Horror"},
            new Category(){ CategoryID = 3, CategoryName="Non Fiction"},
            new Category(){ CategoryID = 4, CategoryName="Self Help"}
            };

            // 1.Display title where pages are greater than 300 and category is 3 or 4 (greater than 2)
            var bookPages = bookList.Where(b => b.Pages >= 300)
                                    .Select(b => b)
                                    .Where(b => b.CategoryID > 2)
                                    .Select(b => b.Title);
            Console.WriteLine("Display title where pages are greater than 300 and category is 3 or 4");

            foreach(var title in bookPages)
            {
                Console.WriteLine(title);
            }

            Console.WriteLine("--------------------------------------------------");

            //"2.Display title of all books between 300 - 400 pages"
            var betweenThreeAndFour = from b in bookList
                                      where b.Pages >= 300 && b.Pages <= 400
                                      select new { Title = b.Title };


            Console.WriteLine("2.Display title of all books between 300 - 400 pages");

            betweenThreeAndFour.ToList().ForEach(b => Console.WriteLine(b.Title));

            Console.WriteLine("--------------------------------------------------");

            // 3.Display ISBN, title, author, pages of books order by ISBN
            var orderByISBN = from b in bookList
                              orderby b.ISBN
                              select new
                              {
                                  isbn = b.ISBN,
                                  title = b.Title,
                                  author = b.Author,
                                  pages = b.Pages
                                 };

            Console.WriteLine("Display ISBN, title, author, pages of books order by ISBN");
            orderByISBN.ToList().ForEach(b => Console.WriteLine("ISBN: {0}, Title: {1}, Author: {2}, Pages {3} ", b.isbn, b.title, b.author, b.pages));

            Console.WriteLine("------------------------------------------------------------");

            //  4.Display ISBN, title, author, pages of books order by category ID and title
            var orderByCatID_Title = from b in bookList
                              orderby b.CategoryID
                              orderby b.Title
                              select new
                              {
                                  isbn = b.ISBN,
                                  title = b.Title,
                                  author = b.Author,
                                  pages = b.Pages
                              };

            Console.WriteLine("Display ISBN, title, author, pages of books order by category ID and title");

            orderByCatID_Title.ToList().ForEach(b => Console.WriteLine("ISBN: {0}, Title: {1}, Author: {2}, Pages {3} ", b.isbn, b.title, b.author, b.pages));

            Console.WriteLine("------------------------------------------------------------");

            // 5.Display groups and titles of different categories
            var groupBooks = from b in bookList
                             group b by b.CategoryID into bg          
                             orderby bg.Key
                             select new { bg.Key, bg };   // this will create 3 groups - standard ID

            Console.WriteLine("Display groups and titles of different categories");
            foreach (var group in groupBooks)
            {
                Console.WriteLine("StandardID {0}:", group.Key);  // this will display the standard

                group.bg.ToList().ForEach(bt => Console.WriteLine(bt.Title));  // this will display the book titles
            }

            Console.WriteLine("------------------------------------------------------------");

            // 6.Use left outer join to group categories but with category descriptions
            var bookGroup = from cl in categoryList
                                join b in bookList
                                on cl.CategoryID equals b.CategoryID
                                    into bg
                                select new
                                {
                                    catName = cl.CategoryName,
                                    book = bg
                                };

            Console.WriteLine("Left outer join:");
            foreach (var group in bookGroup)
            {
                Console.WriteLine(group.catName + ":");  // display categoryName

                group.book.ToList().ForEach(st => Console.WriteLine(st.Title)); // display Title
            }


            // 7. Use inner join to display titles and categories
            Console.WriteLine("------------------------------------------------------------");

            var bookListWithCatList = from b in bookList
                                      join cat in categoryList
                                      on b.CategoryID equals cat.CategoryID
                                      select new
                                      {
                                          bookName = b.Title,
                                          catName = cat.CategoryName
                                      };

            Console.WriteLine("Inner Join:");
            bookListWithCatList.ToList().ForEach(b => Console.WriteLine("{0} has a category of {1}", b.bookName, b.catName));




        } // end main
    } // end class

    class Book
    {
        public string ISBN { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public int Pages { get; set; }
        public int CategoryID { get; set; }
    } // end class

    class Category
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
    } // end class
} // end namespace
