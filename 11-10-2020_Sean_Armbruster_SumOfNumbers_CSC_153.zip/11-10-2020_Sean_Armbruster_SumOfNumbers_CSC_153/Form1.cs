﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _11_10_2020_Sean_Armbruster_SumOfNumbers_CSC_153
{
    public partial class CSC_153_420 : Form
    {
        public CSC_153_420()
        {
            InitializeComponent();
        } // end CSC_153_420

        private bool InputValidation(string s)
        {
            bool validity = true;
            int i = 0;

            if (s != "" && s != null)
            {
                while (i < s.Length && validity)
                {
                    if (char.IsDigit(s[i]) && s[i] == ',')
                    {
                        validity = false;
                    } // end if

                    i++;

                } // end while

            } // end if
            else
            {
                validity = false;
            }

            return validity;

        } // end InputValidation

        private double SumOfString(string s)
        {
            double total = 0;
            s = s.Trim();

            char[] delimeter = { ',' };
            string[] token = s.Split(delimeter);

            try
            {
                foreach (string t in token)
                {
                    total += int.Parse(t);
                }// end foreach
            }// end try
            catch
            {
                MessageBox.Show("Enter a New Input");
            }// end catch

            return total;

        } // end SumOfString

        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            double sumNums;

            if (InputValidation(input))
            {
                sumNums = SumOfString(input);
                MessageBox.Show("Your Sum is: " + sumNums);
            } // end if
            else
            {
                MessageBox.Show("Not a valid input");
            }

        } // end button1_Click

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void CSC_153_420_Load(object sender, EventArgs e)
        {

        }
    } // end partial Class
} // end namespace
