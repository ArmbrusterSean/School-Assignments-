//
//  ViewController.swift
//  Armbruster Apple Pie
//
//  Sean Armbruster
// 4/2/2021
// This program creates a game in which the user guesses the correct word
// if answered wrong, an apple dissappears from the tree.
//

import UIKit

class ViewController: UIViewController {
    
    // list of words
    var listOfWords = [
        "durham", "raleigh", "carrboro", "greensboro", "statesville"
    ]
    
    //constanct variable for incorrect words allowed
    let incorrectWordsAllowed = 7
    
    // variables for total wins and losses
    var totalWins = 0 //{ didSet{ newRound() } }
    var totalLosses = 0 //{ didSet { newRound() } }
    
    var playerScore: Int  = 0         // variable to hold player score value

    
    @IBOutlet var newWord: UIButton!    // outlet for new word button
    
    @IBOutlet var treeImageView: UIImageView!  // outlet for tree images
    
    @IBOutlet var correctWordLabel: UILabel!   //outlet for correct word label
    
    @IBOutlet var scoreLabel: UILabel!         //outlet for score label
    
    @IBOutlet var letterButtons: [UIButton]!   // collection of letter buttons outlets
    
    override func viewDidLoad() {
        super.viewDidLoad()
        newRound()                   //call to start new round
    }

    // letter buttons pressed
    @IBAction func letterButtonpressed(_ sender: UIButton) {
        sender.isEnabled = false
       
        // when button is pressed, sender is diplayed in label if corresponds with word 
        let letterString = sender.title(for: .normal)!
        let letter = Character(letterString.lowercased())
        
        // test for the correct letter
        currentGame.playerGuessed(letter: letter)
        
        // if the letter guessed is contained in the word, playerScore increases by 10
        if currentGame.formattedWord.contains(letter){
            playerScore += 10
            updateUI()
        }

        //update the gameState
        updateGameState()
    }
    
    // button for New Word will create new word only when number of guesses is over or word has been completed
    // this button is hidden until criterion is met 
    @IBAction func newWordButton(_ sender: UIButton) {
        if listOfWords.isEmpty{
            enableLetterButtons(false)  //disable keyboard

        } else {
            newRound()                  
            sender.isHidden = true      // unhide new word button
        }
    }
    
    
    var currentGame: Game!      // initialize Game struct
    // this function starts a new game
    func newRound() {
        
        // test for empty list of words
        if !listOfWords.isEmpty {
            // remove first word from list and store it in this variable
            let newWord = listOfWords.removeFirst()
            
            // create a game / call the game struct
            currentGame = Game(word: newWord, incorrectMovesRemaining: incorrectWordsAllowed, guessedLetters: [])
            
            // enable letterButtons for new round
            enableLetterButtons(true)
            
            // update the UI with the updateUI function
            updateUI()
        } else {
            enableLetterButtons(false)      //disable buttons// game is over
        }
    }
    
    // this function enables the buttons again for a new round
    func enableLetterButtons ( _ enable: Bool) {
        for button in letterButtons {
            button.isEnabled = enable
        }
    }
    
    // this function will update the UI
    func updateUI() {
        
        // add spaces to the underscores
        var letters = [String]()
        for letter in currentGame.formattedWord {
            letters.append(String(letter))
        }
        let wordWithSpacing = letters.joined(separator: " ")
        
        // display the correct letters in accordance with the wordWithSpacing requirements
        correctWordLabel.text = wordWithSpacing
        
        //update the totalWins and totalLosses labels
        scoreLabel.text = "Wins: \(totalWins), Losses: \(totalLosses), Player Score: \(playerScore)"
        
        // update treeImage with corresponding incorrectMovesRemaining
        // call the incorrectMovesRemaining within the currentGame reference to the game struct
        treeImageView.image = UIImage(named: "Tree \(currentGame.incorrectMovesRemaining)")
    }
    
    // this function updates the total wins and losses and playerScore
    func updateGameState() {
        if currentGame.incorrectMovesRemaining == 0 {
            totalLosses += 1
            newWord.isHidden = false        // unhide the new word button
        } else if currentGame.word == currentGame.formattedWord {
            totalWins += 1
            playerScore += 100              // increase player score by 100
            updateUI()                      // update UI upon winning
            newWord.isHidden = false        // unhide the new word button
            
        } else {
            updateUI()                      // update UI 
        }

    }
}

