﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;


/** 
* Sean Armbruster 
* CSC-153-420
* Course Information Program
*
**/
namespace _11_14_2020_SeanArmbruster_CSC153_CourseInformation
{

public partial class CSC_153_420 : Form
    {
        // dictionary with course numbers as keys and room numbers as values
        private Dictionary<string, string> courseRoom = new Dictionary<string, string>()
        {
            {"CS101","3004"},
            {"CS102","4501"},
            {"CS103","6775"},
            {"NT110","1244"},
            {"CM241","1411"},
        };// end dictionary

        // dictionary with course number as key and instructor as values 
        private Dictionary<string, string> courseInstructor = new Dictionary<string, string>()
        {
            {"CS101","Haynes"},
            {"CS102","Alvarado"},
            {"CS103","Rich"},
            {"NT110","Burke"},
            {"CM241","Lee"},
        };// end dictionary

        // dictionary with course number as key and instructor as values 
        private Dictionary<string, string> courseTime = new Dictionary<string, string>()
        {
            {"CS101","8:00am"},
            {"CS102","9:00am"},
            {"CS103","10:00am"},
            {"NT110","11:00am"},
            {"CM241","1:00pm"},
        };// end dictionary

        public CSC_153_420()
        {
            InitializeComponent();
        } // end CSC_153_420

        private void button1_Click(object sender, EventArgs e)
        {
            var course = textBox1.Text;

            // input validation for the string input and utilization of the ContainsKey method to display results.
            if(!string.IsNullOrEmpty(course) && courseRoom.ContainsKey(course))
            {
                MessageBox.Show("Course: " + course + "\nInstructor: " + courseInstructor[course] + "\nRoom: " + courseRoom[course] + "\nTime: " + courseTime[course]);
                textBox1.Clear();
            }// end if

            else
            {
                MessageBox.Show("Invalid Course. \nPlease Enter a Course Number.");
                textBox1.Clear();
            } // end else


        } // end button_1
    }// end partial class 
}// end namespace
