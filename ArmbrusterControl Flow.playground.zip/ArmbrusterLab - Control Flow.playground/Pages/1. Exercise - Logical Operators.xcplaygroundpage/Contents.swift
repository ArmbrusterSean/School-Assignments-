/*:
 ## Exercise - Logical Operators

 For each of the logical expressions below, print out what you think the resulting value will be (`true` or `false`). Then print out the actual expression to see if you were right. An example has been provided below.
 
    43 == 53
    print(false)
    print(43 == 53)

 
 1. `9 == 9`
 */
/**
 Sean Armbruster
 1/28/2021
 Purpose: This assignment uses examples of Logical Operators to implement Control Flow
 */

// 9 is equal to 9, in binary value
print(true)
/*:
 2. `9 != 9`
 */
print(false)
// 9 is equal to 9
/*: 
 3. `47 > 90`
 */
print(false)
// 47 < 90

/*:
 4. `47 < 90`
 */
print(true)

/*:
 5. `4 <= 4`
 */
print(true)
// 4 is less than/equal to 4
/*:
 6. `4 >= 5`
 */
print(false)
// 4 is less than 5
/*:
 7. `(47 > 90) && (47 < 90)`
 */
print(false)
// 47 is only less than 90
/*:
 8. `(47 > 90) || (47 < 90)`
 */
print(true)
// 47 < 90 is true in this statement

/*:
 9. `!true`
 */
print(false)

//: page 1 of 9  |  [Next: Exercise - If and If-Else Statements](@next)
