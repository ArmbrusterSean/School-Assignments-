/**
* Sean Armbruster 
* This is the CruiseShip.h file - derives from Ship class 
**/

#ifndef CRUISESHIP_H
#define CRUISESHIP_H
#include <iostream>
#include <string>
#include "Ship.h"

using namespace std;

// Cruis ship class inherets from Ship Class
class CruiseShip : public Ship {

private:
	int maxPassengers;

public:
	// default constructor - calls from Ship default constructor as well 
	CruiseShip() : Ship() {
		// set max passenger to 0
		maxPassengers = 0;
	}

	// overloaded constructor - calls from overload consstructor from Ship 
	CruiseShip(int mp, string n, string y) : Ship(n, y) {
		maxPassengers = mp;
	}

	// getter function
	int getMaxPassengers() const { return maxPassengers; }

	// setter function 
	void setMaxPassengers(int mp) { maxPassengers = mp; }

	// override print() virtual function 
	virtual void print() const {
		cout << "Name: " << name << endl;
		cout << "Build Year: " << year << endl;
		cout << "Maximum Passengers: " << maxPassengers << endl;
	}
};


#endif // !CRUISESHIP_H
