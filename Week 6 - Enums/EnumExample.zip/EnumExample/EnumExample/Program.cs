﻿using System;
using System.Collections.Generic;

namespace EnumExample
{
    class Program
    {
        static void Main(string[] args)
        {

            //create list of tasks 
            List<Todo> todos = new List<Todo>()
            {
                new Todo { Desciription = "Grocery shop", EstimaedHours=3, Status = Status.NotStarted, Days = Days.Monday },
                new Todo { Desciription = "Ride Bike", EstimaedHours=2, Status = Status.InProg, Days = Days.Saturday },
                new Todo { Desciription = "Do Homework", EstimaedHours=5, Status = Status.Deleted, Days = Days.Thursday },
                new Todo { Desciription = "Buy Booze", EstimaedHours=1, Status = Status.Completed, Days = Days.Tuesday },
                new Todo { Desciription = "Clean House", EstimaedHours=2, Status = Status.OnHold, Days = Days.Wednesday }

            };

            foreach (var task in todos)
            {
                switch (task.Status)
                {
                    case Status.Completed:
                        Console.ForegroundColor = ConsoleColor.Red;
                        break;
                    case Status.Deleted:
                        Console.ForegroundColor = ConsoleColor.Blue;
                        break;
                    case Status.OnHold:
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case Status.InProg:
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        break;
                    case Status.NotStarted:
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        break;
                } //end switch

                // display 
                Console.WriteLine(task.Desciription);

                // pause 
                Console.ReadLine();
            } // end foreach

            // foreach days
            foreach (var task1 in todos)
            {
                switch (task1.Days)
                {
                    case Days.Monday:
                        Console.WriteLine(task1.Desciription + " will be completed on Monday");
                        break;
                    case Days.Tuesday:
                        Console.WriteLine(task1.Desciription + " will be completed on Tuesday");
                        break;
                    case Days.Wednesday:
                        Console.WriteLine(task1.Desciription + " will be completed on Wednesday");
                        break;
                    case Days.Thursday:
                        Console.WriteLine(task1.Desciription + " will be completed on Thursday");
                        break;
                    case Days.Friday:
                        Console.WriteLine(task1.Desciription + " will be completed on Friday");
                        break;
                    case Days.Saturday:
                        Console.WriteLine(task1.Desciription + " will be completed on Saturday");
                        break;
                    case Days.Sunday:
                        Console.WriteLine(task1.Desciription + " will be completed on Sunday");
                        break;
                } // end switch 
            } // end foreach 

            // pause 
            Console.ReadLine();

        } // end main 
    } // end class 

    class Todo
    {
        public string Desciription { get; set;  }

        public int EstimaedHours { get; set; }

        public Status Status { get; set; }

        public Days Days { get; set; }

    } // end Todo Class 

    enum Status
    {
        NotStarted, 
        InProg,
        OnHold,
        Completed,
        Deleted
    } // end Status enum

    enum Days
    {
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday,
        Sunday
    } // end Days enum 
} // end namespace 
