//
//  ViewController.swift
//  ArmbrusterLight
//
//  Created by Sean Armbruster on 2/22/21.
//  This app creates a button that when pressed, turns the screen black (on) and white (off)
//

import UIKit

class ViewController: UIViewController {
    
    //outlet for button
   // @IBOutlet var lightButton: UIButton!
    
    //initialize light variable : Bool
    var lightOn = true
    
// call the updateUI function
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
        // Do any additional setup after loading the view.
    }

// this function tests for the toggle of the button
    fileprivate func updateUI() {
       /** if lightOn {
            view.backgroundColor = .white
           //  lightButton.setTitle("Off", for: .normal)
        }
        else {
            view.backgroundColor = .black
           // lightButton.setTitle("On", for: .normal)
        } **/
        
        view.backgroundColor = lightOn ? .white : .black
    }
    
    // button object 
    @IBAction func buttonPressed(_ sender: Any) {
        lightOn.toggle()
        updateUI()
    }
}

