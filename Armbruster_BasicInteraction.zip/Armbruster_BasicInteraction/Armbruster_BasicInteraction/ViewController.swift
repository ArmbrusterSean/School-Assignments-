//
//  ViewController.swift
//  Armbruster_BasicInteraction
//
//  Sean Armbruster
//  3/26/21.
//  This program showcases IBActions to display text on a labe from a
//  textbox and clearing. 
//

import UIKit

class ViewController: UIViewController {

    //label outlet
    @IBOutlet var label: UILabel!
    
    //text field outlet
    @IBOutlet var textField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    // Start Text Action
    // this funciton implements the texfield input to output to the label
    @IBAction func setTextButtonTapped(_ sender: UIButton) {
        label.text = textField.text
    }
    
    // clear text action
    // this function implements the label and textfield to be empty strings
    @IBAction func clearTextButtonTapped(_ sender: UIButton) {
        label.text = " "
        textField.text = " "
    }
}

