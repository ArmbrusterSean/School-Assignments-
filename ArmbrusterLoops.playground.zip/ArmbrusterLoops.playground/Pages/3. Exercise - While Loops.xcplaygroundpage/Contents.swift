import Foundation
/*:
 ## Exercise - While Loops
 
 Create a while loop that simulates rolling a 6-sided dice repeatedly until a 1 is rolled. After each roll, print the value. (Hint: use `Int.random(in: 1...6)` to generate a random number between 1 and 6).
 */
// this code creates an app that rolls a dice until it rolls a one. A while loop will call a function that determines a random int 1...6 and breaks the loop once a 1 has been rolled

func rollDice() -> Int {
    return Int.random(in: 1...6)
}

var rolls = 0

while rolls >= 0{
    rolls = rollDice()
    print(rolls)
    
    if rolls == 1 {
        break
    }
}
//: [Previous](@previous)  |  page 3 of 6  |  [Next: App Exercise - While Loops](@next)
