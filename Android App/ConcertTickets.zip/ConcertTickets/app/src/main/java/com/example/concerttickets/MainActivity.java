package com.example.concerttickets;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    // Declare vars
    double costPerTicket = 79.99;
    int numberOfTickets;
    double totalCost;
    String groupChoice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText tickets = (EditText) findViewById(R.id.txtTickets);
        final EditText group = (EditText) findViewById(R.id.txtGroup);
        final TextView result = (TextView) findViewById(R.id.txtResults);

        Button cost = (Button) findViewById(R.id.btnCost);

        cost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numberOfTickets = Integer.parseInt(tickets.getText().toString());
                groupChoice = group.getText().toString();
                totalCost = costPerTicket * numberOfTickets;
                // currency format
                DecimalFormat currency = new DecimalFormat("###,###.##");
                result.setText("Cost for " + groupChoice + " is " + currency.format(totalCost));
            }// end onClick
        });



    } // end onCreate
} // end class