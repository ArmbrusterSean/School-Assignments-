﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _12_8_2020_Sean_Armbruster_PhysicsDemo_CSC_153_420
{
    public partial class Form1 : Form
    {

        // graphics variable 
        Graphics g;

        //ball pixel variables 
        int x = 100;
        int y = 100;

        // increment variables//speed.
        // this will be FAST 
        int dx = 10; 
        int dy = 9;

        public Form1()
        {
            InitializeComponent();

            // redraw the ball 
            this.Paint += new PaintEventHandler(paintBall);

            //indicate whether to draw a new ball or not 
            this.DoubleBuffered = true;

        } // end Form1()

        private void paintBall(object sender, PaintEventArgs e)
        {
            // create graphic object e
            g = e.Graphics;

            // color the ball 
            SolidBrush greenBall = new SolidBrush(Color.Green);

            // fill the ball 
            g.FillEllipse(greenBall, x, y, 40, 40);
        } // end paintBall

        // this method when called will move the ball from the starting coordinates 
        private void MoveBall()
        {
            
            int ball_x = x + dx;    //declare increment of ball on x axis
            int ball_y = y + dy;    //declare increment of ball on y axis

            // keep the ball within the form parameters
            if(ball_x < 0 || ball_x > this.ClientSize.Width) dx = -dx;
            if (ball_y < 0 || ball_y > this.ClientSize.Height) dy = -dy;

            //increment ball position
            x += dx;
            y += dy;

            // redraw ball
            Invalidate();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        } //end Form1_Load

        private void timer1_Tick(object sender, EventArgs e)
        {
            MoveBall();
        }// end timer 

    }// end partial class
}//end namespace
