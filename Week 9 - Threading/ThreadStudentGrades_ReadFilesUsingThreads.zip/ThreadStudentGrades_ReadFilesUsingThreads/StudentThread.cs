﻿using System;
using System.IO;
using System.Linq;
using System.Threading;
/**
* Sean Armbruster 
* CSC 253
* 
* student1.txt and student2.txt are two files with 1000 grades in each.
* Use threading methodology to open and read each file, 
* calculate the averages of student1 and student 2, and display the averages on the screen. 
* Finally, display the group who had the higher average.
**/


namespace ThreadStudentGrades_ReadFilesUsingThreads
{
    class StudentThread
    {
        static void Main(string[] args)
        {

            // inititalize Objects 
            TaskStudentOne student1 = new TaskStudentOne();
            TaskStudentTwo student2 = new TaskStudentTwo();

            // pause
            System.Console.ReadLine();

        } // end main 
    } // end StudentThread class

    public class TaskStudentOne
    {
        //field 
        private static string[] file;
        private static int[] values;
        public static double avg;       // needs to be public for wider scope 


        // constructor 
        public TaskStudentOne()
        {
            Thread studentOne = new Thread(new ThreadStart(DisplayStudentOneFile));
            studentOne.Start();
            studentOne.Join();
        }

        // this method reads through the .txt file as an array of strings and displays each element. 
        void DisplayStudentOneFile()
        {
            file = System.IO.File.ReadAllLines("C:/Users/ACER/Desktop/student1.txt");
            double avg = StudetnAvg();

            foreach (string s in file)
            {
                Console.WriteLine("Student One Grades: " + s);
            }
            Console.WriteLine("\nThe average grade for Student One is " + avg);
            Console.WriteLine("\n-------------------------------------------------------\n");
        }

        // This function converts the ReadFile to a string of ints Via LINQ and uses the .Average() method to find the average
        double StudetnAvg()
        {
            {
                values = file.Select((l) => int.Parse(l)).ToArray();
                avg = values.Average();
                return avg;
            }
        }

    }
    public class TaskStudentTwo
    {
        //fields
        private static string[] file;
        private static int[] values;
        public static double avg;       // needs to be public for wider scope 


        // constructor 
        public TaskStudentTwo()
        {
            Thread studentTwo = new Thread(new ThreadStart(DisplayStudentTwoFile));     
            studentTwo.Start();
        }

        void DisplayStudentTwoFile()
        {
            file = System.IO.File.ReadAllLines("C:/Users/ACER/Desktop/student2.txt");
            double avg = StudetnAvg();

            foreach (string s in file)
            {
                Console.WriteLine("Student Two Grades: " + s);
            }
            Console.WriteLine("\n---------------------------------------------------------\n");
            Console.WriteLine("The average grade for Student Two is " + avg);

            Console.WriteLine("\n---------------------------------------------------------\n");
            HighestAvg();       // display the Highest Average 
        }

        // This function converts the ReadFile to a string of ints Via LINQ and uses the .Average() method to find the average
        double StudetnAvg()
        {
            {
                values = file.Select((l) => int.Parse(l)).ToArray();
                avg = values.Average();
                return avg;
            }
        }

        // this method tests to see which class has the higher average and displays
        void HighestAvg()
        {
            if (TaskStudentOne.avg < TaskStudentTwo.avg)
            {
                Console.WriteLine("Student 2 has the higher average at " + TaskStudentTwo.avg);
            }
            else
            {
                Console.WriteLine("Student 1 has the higher average at " + TaskStudentOne.avg);
            }
        }

    }
} // end namespace
