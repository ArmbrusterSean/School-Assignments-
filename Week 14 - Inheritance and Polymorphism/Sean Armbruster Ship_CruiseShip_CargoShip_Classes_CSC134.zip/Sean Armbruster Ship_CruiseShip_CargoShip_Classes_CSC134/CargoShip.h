#ifndef CARGOSHIP_H
#define CARGOSHIP_H
#include "Ship.h"


#include <iostream>
#include <string>

using namespace std;
/**
* Sean Armbruster
* This is the CargoShip.h file - derives from Ship class
**/

// CargoShip Class inherits from Ship Class
class CargoShip : public Ship {
private:
	int maxTons;

public:
	// default constructor - Also calls from Ship Class
	CargoShip() : Ship() {
		maxTons = 0;
	}

	// overloaded constructor - calls from Ship Class 
	CargoShip(int mt, string n, string y) : Ship(n, y) {
		maxTons = mt;
	}

	// getter function 
	int getMaxCapacity() const { return maxTons; }

	// setter function 
	void setMaxTons(int mt) { maxTons = mt; }

	// override print() virtual function 
	virtual void print() const {
		cout << "Name: " << name << endl;
		cout << "Build Year: " << year << endl;
		cout << "Maximum Tons: " << maxTons << endl;
	}
};

#endif // !CARGOSHIP_H
