//
//  Game.swift
//  Armbruster Apple Pie
//
//  Created by Sean Armbruster
//

import Foundation

// stucture for Game
struct Game {
    var word: String
    var incorrectMovesRemaining: Int
    var guessedLetters: [Character]         // array of characters

    // this function tests for correct letter
    mutating func playerGuessed(letter: Character) {
        guessedLetters.append(letter)
        
        // if incorrect letter is pressed, incorrectMovesRemaining decreases by one 
        if !word.contains(letter){
            incorrectMovesRemaining -= 1
        }
    }
    
    // if correct letter is guessed, diplsay the letter, if not, display an underscore
    var formattedWord: String {
        var guessedWord = ""         // holds the empy char 

        for letter in word {
            if guessedLetters.contains(letter) {
                guessedWord += "\(letter)"
    
            } else {
                guessedWord += "_"
            }
        }
        return guessedWord
    }
}
