﻿/** 
 * Sean Armbruster 
 * CSC 253 090
 * Week 2: My Playlist App 
 * This program will use access modifiers and encapsulation to output information regarding an album from an artist.
 * There will be a Class labeled Album that will have 4 fields to keep track of the artist, genre, and copies sold.
 * There will be 3 instances of the Album class with 3 different artists/album/sales.
 * 
 **/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlayList
{
    class Program
    {
        static void Main(string[] args)
        {
            Album album1 = new Album("Masters of Reality",
                                    "Black Sabbath",
                                    "Hard Rock",
                                    12000000,
                                    15.50);

            Album album2 = new Album("Los Angeles",
                                    "X",
                                    "Punk Rock",
                                    1000000,
                                    22.75);

            Album album3 = new Album("Is Dead",
                                    "De La Soul",
                                    "Hip Hop",
                                    21000000,
                                    18.95);

            Console.WriteLine(album1.AlbumInfo());
            Console.WriteLine(album2.AlbumInfo());
            Console.WriteLine(album3.AlbumInfo());


            // pause
            Console.ReadLine();

        } // end main
    } // end Program class 

    class Album
    {
        private string albumTitle;
        private string albumArtist;
        private string albumGenre;
        private double copiesSold;
        private double albumCost;

        // contstructor
        public Album(string albumTitle, string albumArtist, string albumGenre, double copiesSold, double albumCost)
        {
            this.albumTitle = albumTitle;
            this.albumArtist = albumArtist;
            this.albumGenre = albumGenre;
            this.copiesSold = copiesSold;
            this.albumCost = albumCost;
        } // end constructor 

        //getters and setters 
        public string AlbumTitle
        {
            get { return albumTitle; }
            set { albumTitle = value; }
        } // end AlbumTitle
        public string AlbumArtist
        {
            get { return albumArtist; }
            set { albumArtist = value; }
        } // end AlbumArtist 
        public string AlbumGenre
        {
            get { return albumGenre; }
            set { albumGenre = value; }
        }// end AlbumGenre
        public double CopiesSold
        {
            get { return copiesSold; }
            set { copiesSold = value; }
        }// end CopiesSold
        public double AlbumCost
        {
            get { return albumCost; }
            set { albumCost = value; }
        } // end AlbumCost 

        public double moneyMade()
        {
            return albumCost * copiesSold;
        } // end moneyMade

        public string AlbumInfo()
        {
            string v = moneyMade().ToString("N0");
            return "The album " + albumTitle + " by the " + albumGenre + " artist(s) " + albumArtist + " sold " + copiesSold.ToString("N0") + " copies at ~$" + albumCost + " making about $" + v + "\n";
        } // end AblumInfo

    } // end Album class 

}// end namespace
