﻿/**
 * Sean Armbruster 
 * CSC 253
 * 
 * Delegates Assignment: 
 * 
 * Have a Add method, Subtract method, Multiply method, Divide method.
 * Each method will loop 100 times. With each iteration, generate two random numbers (between 1 - 50),
 * then perform the math operation (add for the Add method, subtract for the Subtract method, etc.)
 * 
 * One validation check - for subtraction and division,
 * make sure the higher number generated comes first in the calculation. 
 * 
 * 
 **/
using System;

namespace DelegateMath
{
    class DelegateRandomMath
    {
        //declare delegates 
        public delegate double AddNums(double num1, double num2);
        public delegate double SubNums(double num1, double num2);
        public delegate double MultiplyNums(double num1, double num2);
        public delegate double DivideNums(double num1, double num2);

        static void Main(string[] args)
        {
            int num1 = 0;
            int num2 = 0;

            // inititalize the AddNums delegate with the SumNums method
            Console.WriteLine("Using the AddNums Delegate: ");
            AddNums a = new AddNums(SumNums);
            a.Invoke(num1, num2);

            // initialize the SubNums delegate with the DifferenceNums method 
            Console.WriteLine("\nUsing the SubNums Delegate: ");
            SubNums b = new SubNums(DifferenceNums);
            b.Invoke(num1, num2);

            // initialize the MultiplyNums delegate with the ProductNums method 
            Console.WriteLine("\nUsing the MultiplyNums Delegate: ");
            MultiplyNums c = new MultiplyNums(ProductNums);
            c.Invoke(num1, num2);

            // initialize the Dividenums delegate with the QuotientNums methods 
            Console.WriteLine("\nUsing the DivideNums Delegate: ");
            DivideNums d = new DivideNums(QuotientNums);
            d.Invoke(num1, num2);

            Console.ReadLine();
        } // end main 

        // this method adds two doubles and returns the sum
        public static double SumNums(double x, double y)
        {
            double add;

            for (int i = 1; i <= 100; i++)
            {
                Random r = new Random();
                x = r.Next(1, 50);
                y = r.Next(1, 50);
            }

            add = x + y;
            Console.WriteLine("{0} + {1} = {2}", x, y, add);
            return add;
        }

        // this method subtracts two doubles and returns the difference 
        public static double DifferenceNums(double x, double y)
        {
            double sub;

            for (int i = 1; i <= 100; i++)
            {
                Random r = new Random();
                x = r.Next(1, 50);
                y = r.Next(1, 50);
            }

            if (y < x)
            {
                sub = x - y;
                Console.WriteLine("{0} - {1} = {2}", x, y, sub);
                return sub;  
            }
            else
            {
                sub = y - x;
                Console.WriteLine("{0} - {1} = {2}", y, x, sub);
                return sub;
            }
        }

        // this method multiples two doubles and return the Product 
        public static double ProductNums(double x, double y)
        {
            double prod;

            for (int i = 1; i <= 100; i++)
            {
                Random r = new Random();
                x = r.Next(1, 50);
                y = r.Next(1, 50);
            }

            prod = x * y;
            Console.WriteLine("{0} * {1} = {2}", x, y, prod);
            return prod;
        }

        // this method divides two doubles and returns the quotient
        public static double QuotientNums(double x, double y)
        {
            double div;

            for (int i = 1; i <= 100; i++)
            {
                Random r = new Random();
                x = r.Next(1, 50);
                y = r.Next(1, 50);
            }

            if (y < x)
            {
                div = x / y;
                Console.WriteLine("{0} / {1} = {2}", x, y, div);
                return div;
            }
            else
            {
                div = y / x;
                Console.WriteLine("{0} / {1} = {2}", y, x, div);
                return div;
            }
        }

    } // end class DelegateRandomMath
} // end namespace 

