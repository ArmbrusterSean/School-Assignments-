﻿
namespace WeatherTester
{
    partial class WeatherCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TempConvert = new System.Windows.Forms.GroupBox();
            this.CelToKel = new System.Windows.Forms.GroupBox();
            this.CelToKel_Output = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.CelToKel_Button = new System.Windows.Forms.Button();
            this.CelToKel_Input = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.CelToFar = new System.Windows.Forms.GroupBox();
            this.CelToFahr_Output = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.CelToFahr_Button = new System.Windows.Forms.Button();
            this.CelToFahr_Input = new System.Windows.Forms.TextBox();
            this.CelToFahr = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.FahrToKel_Output = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.FahrToKel_Button = new System.Windows.Forms.Button();
            this.FahrToKel_Input = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.FahrToCelBox = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.FahrToCel_Output = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.FahrToCel_Button = new System.Windows.Forms.Button();
            this.FahrToCel_Input = new System.Windows.Forms.TextBox();
            this.FahrToCel_Label = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.HeatIndex_Input2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.HeatIndex_Output = new System.Windows.Forms.Label();
            this.HeatIndex_Butoon = new System.Windows.Forms.Button();
            this.HeatIndex_Input1 = new System.Windows.Forms.TextBox();
            this.HeatIndexLabel = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.WindChill_Input2 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.WindChill_Output = new System.Windows.Forms.Label();
            this.WindChill_Button = new System.Windows.Forms.Button();
            this.WindChill_Input1 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.RelHum_Input2 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.RelHum_Output = new System.Windows.Forms.Label();
            this.RelHum_Button = new System.Windows.Forms.Button();
            this.RelHum_Input1 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.ConvertToMPH_Button = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.Knots_Output = new System.Windows.Forms.Label();
            this.Knots_Input = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.MPH_Output = new System.Windows.Forms.Label();
            this.ConvertToKnots_Button = new System.Windows.Forms.Button();
            this.MPH_Input = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.weatherTempClear = new System.Windows.Forms.Button();
            this.HeatIndexClear = new System.Windows.Forms.Button();
            this.WindChillClear = new System.Windows.Forms.Button();
            this.RelHumClear = new System.Windows.Forms.Button();
            this.MPHKnotsClear = new System.Windows.Forms.Button();
            this.TempConvert.SuspendLayout();
            this.CelToKel.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.CelToFar.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.FahrToCelBox.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.SuspendLayout();
            // 
            // TempConvert
            // 
            this.TempConvert.BackColor = System.Drawing.SystemColors.ControlDark;
            this.TempConvert.Controls.Add(this.weatherTempClear);
            this.TempConvert.Controls.Add(this.CelToKel);
            this.TempConvert.Controls.Add(this.CelToFar);
            this.TempConvert.Controls.Add(this.groupBox3);
            this.TempConvert.Controls.Add(this.FahrToCelBox);
            this.TempConvert.Location = new System.Drawing.Point(143, 12);
            this.TempConvert.Name = "TempConvert";
            this.TempConvert.Size = new System.Drawing.Size(466, 279);
            this.TempConvert.TabIndex = 0;
            this.TempConvert.TabStop = false;
            this.TempConvert.Text = "Temperature Conversions ";
            // 
            // CelToKel
            // 
            this.CelToKel.BackColor = System.Drawing.SystemColors.ControlLight;
            this.CelToKel.Controls.Add(this.CelToKel_Output);
            this.CelToKel.Controls.Add(this.label12);
            this.CelToKel.Controls.Add(this.groupBox6);
            this.CelToKel.Controls.Add(this.CelToKel_Button);
            this.CelToKel.Controls.Add(this.CelToKel_Input);
            this.CelToKel.Controls.Add(this.label15);
            this.CelToKel.Location = new System.Drawing.Point(21, 191);
            this.CelToKel.Name = "CelToKel";
            this.CelToKel.Size = new System.Drawing.Size(422, 58);
            this.CelToKel.TabIndex = 3;
            this.CelToKel.TabStop = false;
            this.CelToKel.Text = "Celsius To Kelvin";
            // 
            // CelToKel_Output
            // 
            this.CelToKel_Output.AutoSize = true;
            this.CelToKel_Output.BackColor = System.Drawing.SystemColors.Control;
            this.CelToKel_Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.CelToKel_Output.ForeColor = System.Drawing.SystemColors.ControlText;
            this.CelToKel_Output.Location = new System.Drawing.Point(204, 33);
            this.CelToKel_Output.Name = "CelToKel_Output";
            this.CelToKel_Output.Size = new System.Drawing.Size(2, 15);
            this.CelToKel_Output.TabIndex = 5;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(190, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "Your Converted Temperature in Kelvin:";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.button3);
            this.groupBox6.Controls.Add(this.textBox5);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Location = new System.Drawing.Point(0, 97);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(422, 91);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Fahrenheit To Celsius ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(200, 60);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 13);
            this.label13.TabIndex = 3;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(309, 21);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Convert ";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(203, 23);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Location = new System.Drawing.Point(23, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(174, 15);
            this.label14.TabIndex = 0;
            this.label14.Text = "Enter a Temperature In Fahrenheit:";
            // 
            // CelToKel_Button
            // 
            this.CelToKel_Button.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.CelToKel_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CelToKel_Button.Location = new System.Drawing.Point(297, 7);
            this.CelToKel_Button.Name = "CelToKel_Button";
            this.CelToKel_Button.Size = new System.Drawing.Size(75, 23);
            this.CelToKel_Button.TabIndex = 2;
            this.CelToKel_Button.Text = "Convert ";
            this.CelToKel_Button.UseVisualStyleBackColor = false;
            this.CelToKel_Button.Click += new System.EventHandler(this.CelToKel_Button_Click);
            // 
            // CelToKel_Input
            // 
            this.CelToKel_Input.Location = new System.Drawing.Point(170, 10);
            this.CelToKel_Input.Name = "CelToKel_Input";
            this.CelToKel_Input.Size = new System.Drawing.Size(100, 20);
            this.CelToKel_Input.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 18);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(155, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "Enter a Temperature In Celsius:";
            // 
            // CelToFar
            // 
            this.CelToFar.BackColor = System.Drawing.SystemColors.ControlLight;
            this.CelToFar.Controls.Add(this.CelToFahr_Output);
            this.CelToFar.Controls.Add(this.label9);
            this.CelToFar.Controls.Add(this.groupBox5);
            this.CelToFar.Controls.Add(this.CelToFahr_Button);
            this.CelToFar.Controls.Add(this.CelToFahr_Input);
            this.CelToFar.Controls.Add(this.CelToFahr);
            this.CelToFar.Location = new System.Drawing.Point(21, 135);
            this.CelToFar.Name = "CelToFar";
            this.CelToFar.Size = new System.Drawing.Size(422, 53);
            this.CelToFar.TabIndex = 2;
            this.CelToFar.TabStop = false;
            this.CelToFar.Text = "Celsius To Fahrenheit ";
            // 
            // CelToFahr_Output
            // 
            this.CelToFahr_Output.AutoSize = true;
            this.CelToFahr_Output.BackColor = System.Drawing.SystemColors.Control;
            this.CelToFahr_Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.CelToFahr_Output.ForeColor = System.Drawing.SystemColors.ControlText;
            this.CelToFahr_Output.Location = new System.Drawing.Point(219, 29);
            this.CelToFahr_Output.Name = "CelToFahr_Output";
            this.CelToFahr_Output.Size = new System.Drawing.Size(2, 15);
            this.CelToFahr_Output.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 31);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(208, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Your Converted Temperature in Fahrenheit";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.button4);
            this.groupBox5.Controls.Add(this.textBox4);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Location = new System.Drawing.Point(0, 97);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(422, 91);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Fahrenheit To Celsius ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(200, 60);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 13);
            this.label10.TabIndex = 3;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(309, 21);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 2;
            this.button4.Text = "Convert ";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(203, 23);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Location = new System.Drawing.Point(23, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(174, 15);
            this.label11.TabIndex = 0;
            this.label11.Text = "Enter a Temperature In Fahrenheit:";
            // 
            // CelToFahr_Button
            // 
            this.CelToFahr_Button.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.CelToFahr_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CelToFahr_Button.Location = new System.Drawing.Point(297, 5);
            this.CelToFahr_Button.Name = "CelToFahr_Button";
            this.CelToFahr_Button.Size = new System.Drawing.Size(75, 23);
            this.CelToFahr_Button.TabIndex = 2;
            this.CelToFahr_Button.Text = "Convert ";
            this.CelToFahr_Button.UseVisualStyleBackColor = false;
            this.CelToFahr_Button.Click += new System.EventHandler(this.CelToFahr_Button_Click);
            // 
            // CelToFahr_Input
            // 
            this.CelToFahr_Input.Location = new System.Drawing.Point(170, 8);
            this.CelToFahr_Input.Name = "CelToFahr_Input";
            this.CelToFahr_Input.Size = new System.Drawing.Size(100, 20);
            this.CelToFahr_Input.TabIndex = 1;
            // 
            // CelToFahr
            // 
            this.CelToFahr.AutoSize = true;
            this.CelToFahr.Location = new System.Drawing.Point(4, 15);
            this.CelToFahr.Name = "CelToFahr";
            this.CelToFahr.Size = new System.Drawing.Size(155, 13);
            this.CelToFahr.TabIndex = 0;
            this.CelToFahr.Text = "Enter a Temperature In Celsius:";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox3.Controls.Add(this.FahrToKel_Output);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.FahrToKel_Button);
            this.groupBox3.Controls.Add(this.FahrToKel_Input);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Location = new System.Drawing.Point(21, 78);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(422, 51);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Fahrenheit To Kelvin";
            // 
            // FahrToKel_Output
            // 
            this.FahrToKel_Output.AutoSize = true;
            this.FahrToKel_Output.BackColor = System.Drawing.SystemColors.Control;
            this.FahrToKel_Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.FahrToKel_Output.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FahrToKel_Output.Location = new System.Drawing.Point(203, 33);
            this.FahrToKel_Output.Name = "FahrToKel_Output";
            this.FahrToKel_Output.Size = new System.Drawing.Size(2, 15);
            this.FahrToKel_Output.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Your Converted Temperature in Kelvin:";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Controls.Add(this.textBox2);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Location = new System.Drawing.Point(0, 97);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(422, 91);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Fahrenheit To Celsius ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(200, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 13);
            this.label5.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(309, 21);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Convert ";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(203, 23);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Location = new System.Drawing.Point(23, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(174, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "Enter a Temperature In Fahrenheit:";
            // 
            // FahrToKel_Button
            // 
            this.FahrToKel_Button.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.FahrToKel_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.FahrToKel_Button.Location = new System.Drawing.Point(297, 6);
            this.FahrToKel_Button.Name = "FahrToKel_Button";
            this.FahrToKel_Button.Size = new System.Drawing.Size(75, 23);
            this.FahrToKel_Button.TabIndex = 2;
            this.FahrToKel_Button.Text = "Convert ";
            this.FahrToKel_Button.UseVisualStyleBackColor = false;
            this.FahrToKel_Button.Click += new System.EventHandler(this.FahrToKel_Button_Click);
            // 
            // FahrToKel_Input
            // 
            this.FahrToKel_Input.Location = new System.Drawing.Point(184, 9);
            this.FahrToKel_Input.Name = "FahrToKel_Input";
            this.FahrToKel_Input.Size = new System.Drawing.Size(100, 20);
            this.FahrToKel_Input.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(172, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Enter a Temperature In Fahrenheit:";
            // 
            // FahrToCelBox
            // 
            this.FahrToCelBox.BackColor = System.Drawing.SystemColors.ControlLight;
            this.FahrToCelBox.Controls.Add(this.label3);
            this.FahrToCelBox.Controls.Add(this.FahrToCel_Output);
            this.FahrToCelBox.Controls.Add(this.groupBox2);
            this.FahrToCelBox.Controls.Add(this.FahrToCel_Button);
            this.FahrToCelBox.Controls.Add(this.FahrToCel_Input);
            this.FahrToCelBox.Controls.Add(this.FahrToCel_Label);
            this.FahrToCelBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.FahrToCelBox.Location = new System.Drawing.Point(21, 19);
            this.FahrToCelBox.Name = "FahrToCelBox";
            this.FahrToCelBox.Size = new System.Drawing.Size(422, 55);
            this.FahrToCelBox.TabIndex = 0;
            this.FahrToCelBox.TabStop = false;
            this.FahrToCelBox.Text = "Fahrenheit To Celsius ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(194, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Your Converted Temperature in Celsius:";
            // 
            // FahrToCel_Output
            // 
            this.FahrToCel_Output.AutoSize = true;
            this.FahrToCel_Output.BackColor = System.Drawing.SystemColors.Control;
            this.FahrToCel_Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.FahrToCel_Output.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FahrToCel_Output.Location = new System.Drawing.Point(207, 32);
            this.FahrToCel_Output.Name = "FahrToCel_Output";
            this.FahrToCel_Output.Size = new System.Drawing.Size(2, 15);
            this.FahrToCel_Output.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(0, 97);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(422, 91);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Fahrenheit To Celsius ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(200, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(309, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Convert ";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(203, 23);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(23, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Enter a Temperature In Fahrenheit:";
            // 
            // FahrToCel_Button
            // 
            this.FahrToCel_Button.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.FahrToCel_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.FahrToCel_Button.Location = new System.Drawing.Point(297, 11);
            this.FahrToCel_Button.Name = "FahrToCel_Button";
            this.FahrToCel_Button.Size = new System.Drawing.Size(75, 23);
            this.FahrToCel_Button.TabIndex = 2;
            this.FahrToCel_Button.Text = "Convert ";
            this.FahrToCel_Button.UseVisualStyleBackColor = false;
            this.FahrToCel_Button.Click += new System.EventHandler(this.FahrToCel_Button_Click);
            // 
            // FahrToCel_Input
            // 
            this.FahrToCel_Input.Location = new System.Drawing.Point(184, 9);
            this.FahrToCel_Input.Name = "FahrToCel_Input";
            this.FahrToCel_Input.Size = new System.Drawing.Size(100, 20);
            this.FahrToCel_Input.TabIndex = 1;
            // 
            // FahrToCel_Label
            // 
            this.FahrToCel_Label.AutoSize = true;
            this.FahrToCel_Label.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FahrToCel_Label.Location = new System.Drawing.Point(6, 16);
            this.FahrToCel_Label.Name = "FahrToCel_Label";
            this.FahrToCel_Label.Size = new System.Drawing.Size(172, 13);
            this.FahrToCel_Label.TabIndex = 0;
            this.FahrToCel_Label.Text = "Enter a Temperature In Fahrenheit:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox1.Controls.Add(this.groupBox13);
            this.groupBox1.Location = new System.Drawing.Point(143, 293);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(466, 114);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Heat Index";
            // 
            // groupBox13
            // 
            this.groupBox13.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox13.Controls.Add(this.HeatIndexClear);
            this.groupBox13.Controls.Add(this.HeatIndex_Input2);
            this.groupBox13.Controls.Add(this.label7);
            this.groupBox13.Controls.Add(this.label30);
            this.groupBox13.Controls.Add(this.HeatIndex_Output);
            this.groupBox13.Controls.Add(this.HeatIndex_Butoon);
            this.groupBox13.Controls.Add(this.HeatIndex_Input1);
            this.groupBox13.Controls.Add(this.HeatIndexLabel);
            this.groupBox13.Location = new System.Drawing.Point(21, 16);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(422, 87);
            this.groupBox13.TabIndex = 0;
            this.groupBox13.TabStop = false;
            // 
            // HeatIndex_Input2
            // 
            this.HeatIndex_Input2.Location = new System.Drawing.Point(211, 39);
            this.HeatIndex_Input2.Name = "HeatIndex_Input2";
            this.HeatIndex_Input2.Size = new System.Drawing.Size(97, 20);
            this.HeatIndex_Input2.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(181, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Enter Relative Humidity (As Percent):";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(22, 64);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(140, 13);
            this.label30.TabIndex = 4;
            this.label30.Text = "Your Calculated Heat Index:";
            // 
            // HeatIndex_Output
            // 
            this.HeatIndex_Output.AutoSize = true;
            this.HeatIndex_Output.BackColor = System.Drawing.SystemColors.Control;
            this.HeatIndex_Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.HeatIndex_Output.ForeColor = System.Drawing.SystemColors.ControlText;
            this.HeatIndex_Output.Location = new System.Drawing.Point(172, 64);
            this.HeatIndex_Output.Name = "HeatIndex_Output";
            this.HeatIndex_Output.Size = new System.Drawing.Size(2, 15);
            this.HeatIndex_Output.TabIndex = 3;
            // 
            // HeatIndex_Butoon
            // 
            this.HeatIndex_Butoon.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.HeatIndex_Butoon.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.HeatIndex_Butoon.Location = new System.Drawing.Point(317, 10);
            this.HeatIndex_Butoon.Name = "HeatIndex_Butoon";
            this.HeatIndex_Butoon.Size = new System.Drawing.Size(75, 23);
            this.HeatIndex_Butoon.TabIndex = 2;
            this.HeatIndex_Butoon.Text = "Calculate";
            this.HeatIndex_Butoon.UseVisualStyleBackColor = false;
            this.HeatIndex_Butoon.Click += new System.EventHandler(this.HeatIndex_Butoon_Click);
            // 
            // HeatIndex_Input1
            // 
            this.HeatIndex_Input1.Location = new System.Drawing.Point(210, 13);
            this.HeatIndex_Input1.Name = "HeatIndex_Input1";
            this.HeatIndex_Input1.Size = new System.Drawing.Size(98, 20);
            this.HeatIndex_Input1.TabIndex = 1;
            // 
            // HeatIndexLabel
            // 
            this.HeatIndexLabel.AutoSize = true;
            this.HeatIndexLabel.Location = new System.Drawing.Point(21, 16);
            this.HeatIndexLabel.Name = "HeatIndexLabel";
            this.HeatIndexLabel.Size = new System.Drawing.Size(172, 13);
            this.HeatIndexLabel.TabIndex = 0;
            this.HeatIndexLabel.Text = "Enter a Temperature In Fahrenheit:";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Location = new System.Drawing.Point(143, 413);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(466, 114);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Wind Chill";
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox8.Controls.Add(this.WindChillClear);
            this.groupBox8.Controls.Add(this.WindChill_Input2);
            this.groupBox8.Controls.Add(this.label16);
            this.groupBox8.Controls.Add(this.label17);
            this.groupBox8.Controls.Add(this.WindChill_Output);
            this.groupBox8.Controls.Add(this.WindChill_Button);
            this.groupBox8.Controls.Add(this.WindChill_Input1);
            this.groupBox8.Controls.Add(this.label19);
            this.groupBox8.Location = new System.Drawing.Point(21, 19);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(422, 88);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = " ";
            // 
            // WindChill_Input2
            // 
            this.WindChill_Input2.Location = new System.Drawing.Point(211, 35);
            this.WindChill_Input2.Name = "WindChill_Input2";
            this.WindChill_Input2.Size = new System.Drawing.Size(97, 20);
            this.WindChill_Input2.TabIndex = 6;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(108, 42);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(85, 13);
            this.label16.TabIndex = 5;
            this.label16.Text = "Enter Wind Chill:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(23, 68);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(161, 13);
            this.label17.TabIndex = 4;
            this.label17.Text = "Your Calculated Heat Wind Chill:";
            // 
            // WindChill_Output
            // 
            this.WindChill_Output.AutoSize = true;
            this.WindChill_Output.BackColor = System.Drawing.SystemColors.Control;
            this.WindChill_Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.WindChill_Output.ForeColor = System.Drawing.SystemColors.ControlText;
            this.WindChill_Output.Location = new System.Drawing.Point(191, 66);
            this.WindChill_Output.Name = "WindChill_Output";
            this.WindChill_Output.Size = new System.Drawing.Size(2, 15);
            this.WindChill_Output.TabIndex = 3;
            // 
            // WindChill_Button
            // 
            this.WindChill_Button.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.WindChill_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.WindChill_Button.Location = new System.Drawing.Point(317, 7);
            this.WindChill_Button.Name = "WindChill_Button";
            this.WindChill_Button.Size = new System.Drawing.Size(75, 23);
            this.WindChill_Button.TabIndex = 2;
            this.WindChill_Button.Text = "Calculate";
            this.WindChill_Button.UseVisualStyleBackColor = false;
            this.WindChill_Button.Click += new System.EventHandler(this.WindChill_Button_Click);
            // 
            // WindChill_Input1
            // 
            this.WindChill_Input1.Location = new System.Drawing.Point(210, 9);
            this.WindChill_Input1.Name = "WindChill_Input1";
            this.WindChill_Input1.Size = new System.Drawing.Size(98, 20);
            this.WindChill_Input1.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(21, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(172, 13);
            this.label19.TabIndex = 0;
            this.label19.Text = "Enter a Temperature In Fahrenheit:";
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Location = new System.Drawing.Point(143, 533);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(466, 115);
            this.groupBox9.TabIndex = 3;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Relative Humidity";
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox10.Controls.Add(this.RelHumClear);
            this.groupBox10.Controls.Add(this.RelHum_Input2);
            this.groupBox10.Controls.Add(this.label18);
            this.groupBox10.Controls.Add(this.label20);
            this.groupBox10.Controls.Add(this.RelHum_Output);
            this.groupBox10.Controls.Add(this.RelHum_Button);
            this.groupBox10.Controls.Add(this.RelHum_Input1);
            this.groupBox10.Controls.Add(this.label22);
            this.groupBox10.Location = new System.Drawing.Point(21, 19);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(422, 88);
            this.groupBox10.TabIndex = 0;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = " ";
            // 
            // RelHum_Input2
            // 
            this.RelHum_Input2.Location = new System.Drawing.Point(207, 39);
            this.RelHum_Input2.Name = "RelHum_Input2";
            this.RelHum_Input2.Size = new System.Drawing.Size(97, 20);
            this.RelHum_Input2.TabIndex = 6;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(37, 42);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(143, 13);
            this.label18.TabIndex = 5;
            this.label18.Text = "Enter Actual Vapor Pressure:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(14, 66);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(170, 13);
            this.label20.TabIndex = 4;
            this.label20.Text = "Your Calculated Relative Humidity:";
            // 
            // RelHum_Output
            // 
            this.RelHum_Output.AutoSize = true;
            this.RelHum_Output.BackColor = System.Drawing.SystemColors.Control;
            this.RelHum_Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.RelHum_Output.ForeColor = System.Drawing.SystemColors.ControlText;
            this.RelHum_Output.Location = new System.Drawing.Point(198, 66);
            this.RelHum_Output.Name = "RelHum_Output";
            this.RelHum_Output.Size = new System.Drawing.Size(2, 15);
            this.RelHum_Output.TabIndex = 3;
            // 
            // RelHum_Button
            // 
            this.RelHum_Button.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.RelHum_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RelHum_Button.Location = new System.Drawing.Point(317, 11);
            this.RelHum_Button.Name = "RelHum_Button";
            this.RelHum_Button.Size = new System.Drawing.Size(75, 22);
            this.RelHum_Button.TabIndex = 2;
            this.RelHum_Button.Text = "Calculate";
            this.RelHum_Button.UseVisualStyleBackColor = false;
            this.RelHum_Button.Click += new System.EventHandler(this.RelHum_Button_Click);
            // 
            // RelHum_Input1
            // 
            this.RelHum_Input1.Location = new System.Drawing.Point(206, 13);
            this.RelHum_Input1.Name = "RelHum_Input1";
            this.RelHum_Input1.Size = new System.Drawing.Size(98, 20);
            this.RelHum_Input1.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(21, 16);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(159, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "Enter Saturated Vapor Pressure:";
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox11.Controls.Add(this.groupBox12);
            this.groupBox11.Location = new System.Drawing.Point(143, 654);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(466, 160);
            this.groupBox11.TabIndex = 4;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "MPH and Knots Conversion";
            // 
            // groupBox12
            // 
            this.groupBox12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox12.Controls.Add(this.MPHKnotsClear);
            this.groupBox12.Controls.Add(this.ConvertToMPH_Button);
            this.groupBox12.Controls.Add(this.label26);
            this.groupBox12.Controls.Add(this.Knots_Output);
            this.groupBox12.Controls.Add(this.Knots_Input);
            this.groupBox12.Controls.Add(this.label21);
            this.groupBox12.Controls.Add(this.label23);
            this.groupBox12.Controls.Add(this.MPH_Output);
            this.groupBox12.Controls.Add(this.ConvertToKnots_Button);
            this.groupBox12.Controls.Add(this.MPH_Input);
            this.groupBox12.Controls.Add(this.label25);
            this.groupBox12.Location = new System.Drawing.Point(21, 19);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(422, 127);
            this.groupBox12.TabIndex = 0;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = " ";
            // 
            // ConvertToMPH_Button
            // 
            this.ConvertToMPH_Button.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ConvertToMPH_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ConvertToMPH_Button.Location = new System.Drawing.Point(297, 59);
            this.ConvertToMPH_Button.Name = "ConvertToMPH_Button";
            this.ConvertToMPH_Button.Size = new System.Drawing.Size(109, 29);
            this.ConvertToMPH_Button.TabIndex = 9;
            this.ConvertToMPH_Button.Text = "Convert to MPH";
            this.ConvertToMPH_Button.UseVisualStyleBackColor = false;
            this.ConvertToMPH_Button.Click += new System.EventHandler(this.ConvertToMPH_Button_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(56, 46);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(153, 13);
            this.label26.TabIndex = 8;
            this.label26.Text = "Your MPH Converted to Knots:";
            // 
            // Knots_Output
            // 
            this.Knots_Output.AutoSize = true;
            this.Knots_Output.BackColor = System.Drawing.SystemColors.Control;
            this.Knots_Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Knots_Output.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Knots_Output.Location = new System.Drawing.Point(240, 46);
            this.Knots_Output.Name = "Knots_Output";
            this.Knots_Output.Size = new System.Drawing.Size(2, 15);
            this.Knots_Output.TabIndex = 7;
            // 
            // Knots_Input
            // 
            this.Knots_Input.Location = new System.Drawing.Point(139, 72);
            this.Knots_Input.Name = "Knots_Input";
            this.Knots_Input.Size = new System.Drawing.Size(97, 20);
            this.Knots_Input.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(73, 75);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 13);
            this.label21.TabIndex = 5;
            this.label21.Text = "Enter Knots:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(56, 104);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(150, 13);
            this.label23.TabIndex = 4;
            this.label23.Text = "Your Knots Converted to MPH";
            // 
            // MPH_Output
            // 
            this.MPH_Output.AutoSize = true;
            this.MPH_Output.BackColor = System.Drawing.SystemColors.Control;
            this.MPH_Output.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MPH_Output.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MPH_Output.Location = new System.Drawing.Point(240, 104);
            this.MPH_Output.Name = "MPH_Output";
            this.MPH_Output.Size = new System.Drawing.Size(2, 15);
            this.MPH_Output.TabIndex = 3;
            // 
            // ConvertToKnots_Button
            // 
            this.ConvertToKnots_Button.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ConvertToKnots_Button.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ConvertToKnots_Button.Location = new System.Drawing.Point(297, 8);
            this.ConvertToKnots_Button.Name = "ConvertToKnots_Button";
            this.ConvertToKnots_Button.Size = new System.Drawing.Size(109, 29);
            this.ConvertToKnots_Button.TabIndex = 2;
            this.ConvertToKnots_Button.Text = "Convert to Knots ";
            this.ConvertToKnots_Button.UseVisualStyleBackColor = false;
            this.ConvertToKnots_Button.Click += new System.EventHandler(this.ConvertToKnots_Button_Click);
            // 
            // MPH_Input
            // 
            this.MPH_Input.Location = new System.Drawing.Point(147, 13);
            this.MPH_Input.Name = "MPH_Input";
            this.MPH_Input.Size = new System.Drawing.Size(98, 20);
            this.MPH_Input.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(57, 16);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(90, 13);
            this.label25.TabIndex = 0;
            this.label25.Text = "Enter Wind MPH:";
            // 
            // weatherTempClear
            // 
            this.weatherTempClear.BackColor = System.Drawing.SystemColors.Info;
            this.weatherTempClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.weatherTempClear.Location = new System.Drawing.Point(205, 251);
            this.weatherTempClear.Name = "weatherTempClear";
            this.weatherTempClear.Size = new System.Drawing.Size(75, 23);
            this.weatherTempClear.TabIndex = 6;
            this.weatherTempClear.Text = "Clear";
            this.weatherTempClear.UseVisualStyleBackColor = false;
            this.weatherTempClear.Click += new System.EventHandler(this.weatherTempClear_Click);
            // 
            // HeatIndexClear
            // 
            this.HeatIndexClear.BackColor = System.Drawing.SystemColors.Info;
            this.HeatIndexClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.HeatIndexClear.Location = new System.Drawing.Point(317, 39);
            this.HeatIndexClear.Name = "HeatIndexClear";
            this.HeatIndexClear.Size = new System.Drawing.Size(75, 23);
            this.HeatIndexClear.TabIndex = 7;
            this.HeatIndexClear.Text = "Clear";
            this.HeatIndexClear.UseVisualStyleBackColor = false;
            this.HeatIndexClear.Click += new System.EventHandler(this.HeatIndexClear_Click);
            // 
            // WindChillClear
            // 
            this.WindChillClear.BackColor = System.Drawing.SystemColors.Info;
            this.WindChillClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.WindChillClear.Location = new System.Drawing.Point(317, 37);
            this.WindChillClear.Name = "WindChillClear";
            this.WindChillClear.Size = new System.Drawing.Size(75, 23);
            this.WindChillClear.TabIndex = 8;
            this.WindChillClear.Text = "Clear";
            this.WindChillClear.UseVisualStyleBackColor = false;
            this.WindChillClear.Click += new System.EventHandler(this.WindChillClear_Click);
            // 
            // RelHumClear
            // 
            this.RelHumClear.BackColor = System.Drawing.SystemColors.Info;
            this.RelHumClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RelHumClear.Location = new System.Drawing.Point(317, 41);
            this.RelHumClear.Name = "RelHumClear";
            this.RelHumClear.Size = new System.Drawing.Size(75, 22);
            this.RelHumClear.TabIndex = 9;
            this.RelHumClear.Text = "Clear";
            this.RelHumClear.UseVisualStyleBackColor = false;
            this.RelHumClear.Click += new System.EventHandler(this.RelHumClear_Click);
            // 
            // MPHKnotsClear
            // 
            this.MPHKnotsClear.BackColor = System.Drawing.SystemColors.Info;
            this.MPHKnotsClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.MPHKnotsClear.Location = new System.Drawing.Point(317, 95);
            this.MPHKnotsClear.Name = "MPHKnotsClear";
            this.MPHKnotsClear.Size = new System.Drawing.Size(75, 22);
            this.MPHKnotsClear.TabIndex = 10;
            this.MPHKnotsClear.Text = "Clear";
            this.MPHKnotsClear.UseVisualStyleBackColor = false;
            this.MPHKnotsClear.Click += new System.EventHandler(this.MPHKnotsClear_Click);
            // 
            // WeatherCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(714, 845);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TempConvert);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "WeatherCalculator";
            this.Text = "Weather Calculator";
            this.TempConvert.ResumeLayout(false);
            this.CelToKel.ResumeLayout(false);
            this.CelToKel.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.CelToFar.ResumeLayout(false);
            this.CelToFar.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.FahrToCelBox.ResumeLayout(false);
            this.FahrToCelBox.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox TempConvert;
        private System.Windows.Forms.GroupBox FahrToCelBox;
        private System.Windows.Forms.TextBox FahrToCel_Input;
        private System.Windows.Forms.Label FahrToCel_Label;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label FahrToKel_Output;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button FahrToKel_Button;
        private System.Windows.Forms.TextBox FahrToKel_Input;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label FahrToCel_Output;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button FahrToCel_Button;
        private System.Windows.Forms.GroupBox CelToFar;
        private System.Windows.Forms.Label CelToFahr_Output;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button CelToFahr_Button;
        private System.Windows.Forms.TextBox CelToFahr_Input;
        private System.Windows.Forms.Label CelToFahr;
        private System.Windows.Forms.GroupBox CelToKel;
        private System.Windows.Forms.Label CelToKel_Output;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button CelToKel_Button;
        private System.Windows.Forms.TextBox CelToKel_Input;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox HeatIndex_Input2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label HeatIndex_Output;
        private System.Windows.Forms.Button HeatIndex_Butoon;
        private System.Windows.Forms.TextBox HeatIndex_Input1;
        private System.Windows.Forms.Label HeatIndexLabel;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox WindChill_Input2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label WindChill_Output;
        private System.Windows.Forms.Button WindChill_Button;
        private System.Windows.Forms.TextBox WindChill_Input1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox RelHum_Input2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label RelHum_Output;
        private System.Windows.Forms.Button RelHum_Button;
        private System.Windows.Forms.TextBox RelHum_Input1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button ConvertToMPH_Button;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label Knots_Output;
        private System.Windows.Forms.TextBox Knots_Input;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label MPH_Output;
        private System.Windows.Forms.Button ConvertToKnots_Button;
        private System.Windows.Forms.TextBox MPH_Input;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button weatherTempClear;
        private System.Windows.Forms.Button HeatIndexClear;
        private System.Windows.Forms.Button WindChillClear;
        private System.Windows.Forms.Button RelHumClear;
        private System.Windows.Forms.Button MPHKnotsClear;
    }
}

