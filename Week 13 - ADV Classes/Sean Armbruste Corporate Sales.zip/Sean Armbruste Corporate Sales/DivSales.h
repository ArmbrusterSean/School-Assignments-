#pragma once
#ifndef  DIVSALES_H
#define DIVSALES_H

#include <iostream>
#include <string>

using namespace std;

class DivSales {

private:
	//hold sales values - four quarters 
	double quarterlySales[4];

	// hold total corporatte sales for all divisions for entire year 
	static double corporateTotal;

public:
	// set the four quarterly sales for division 
	void setQuarterlySales(double q1, double q2, double q3, double q4) {
		//input validaiton - if sales are negative
		if (q1 < 0 || q2 < 0 || q3 < 0 || q4 < 0) {
			cout << "Sales number must be positive!" << endl;
		}
		else {
			// else set values 
			quarterlySales[0] = q1;
			quarterlySales[1] = q2;
			quarterlySales[2] = q3;
			quarterlySales[3] = q4;

			// add to corporateTotal 
			corporateTotal += q1 + q2 + q3 + q4;
		}
	}

	// get sales for specific quarter and return value of array element 
	double getQaurter(int q) {
		// input validation - if subscript is out of range - error
		if (q < 0 || q > 3) {
			cout << "Error! " << endl;
		}
		else {
			// return value for requeated quarter 
			return quarterlySales[q];
		}
	}

	// return corporateTotal
	double getCorporateTotal() {
		return corporateTotal;
	}
};

double DivSales::corporateTotal = 0.0;









#endif // ! DIVSALES_H
