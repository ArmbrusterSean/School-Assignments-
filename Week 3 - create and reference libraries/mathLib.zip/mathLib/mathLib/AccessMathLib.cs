﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mathLib
{
    /// <summary>
    /// This class will contain three Overloaded methdos 
    /// 1st method will accept 2 int parameters and return the larger #
    /// 2nd method will accept 3 ints and retrun the larger #
    /// 3rd method will accept 4 ints and return the larger #
    /// </summary>
   
    public class AccessMathLib
    {
        public int getLargestInt(int a, int b)
        {
            if (a > b)
            {
                return a;
            } // end if 
            else
            {
                return b;
            } // end else 
        }// end getLargestInt 

        public int getLargestInt(int a, int b, int c)
        {
            if(a > b && a > c)
            {
                return a;
            } // end if 
            else if (b > a && b > c)
            {
                return b;
            } // end else if
            else
            {
                return c;
            } // end else 
        } // end getLargestInt 

        public int getLargestInt(int a, int b, int c, int d)
        {
            if (a > b && a > c && a > d)
            {
                return a;
            } // end if 
            else if (b > a && b > c && a > d)
            {
                return b;
            } // end else if
            else if (c > a && c > b && c > d)
            {
                return c;
            } // end else if
            else
            {
                return d;
            } // end else 
        }// end getLargestInt


    } // end AccessMathLib
} // end namespace
