﻿/**
 * Sean Armbruster 
 * CSC 253
 * Week 6 : Enums 
1. Create a class of HelpDeskCalls with the following properties:
Description of problem, Date reported, Status, Priority, Person who reported problem, Notes
Make sure that Status is an enum type (NotStarted, InProg, Completed, Unresolved); also make sure Priority is an enum type (Low, Medium, High) 

2. In Main, create a List of Calls with at least 5 items (put in test data, make Status and Priority data different for testing; keep Notes property blank).

3. Use foreach / switch / if statements for the following:
if NotStarted, store "Just reported" in the Notes property.
if InProg, store "Help Desk personnel on scene" in the Notes property.
if Completed, store "Ticket is complete" in the Notes property.
if Unresolved, store "Ongoing investigation" in the Notes property.
Print the Description of problem, Date reported, Status, Priority, Person who reported problem, and Notes.

4. Use foreach / switch for the following:
if Priority is Low, write "The problem is on the back-burner." on the console.
if Priority is Medium, write "The problem is important." on the console.
if Priority is High, write "The problem is critical." on the console.
 * 
 **/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumHelpDesk
{
    class Program
    {
        static void Main(string[] args)
        {

            // create list
            List<HelpDeskCalls> calls = new List<HelpDeskCalls>()
            {
                new HelpDeskCalls { ProblemDescription = "Can't turn printer on", DateReported = "2/22/21", PersonReported = "Ferf Nerckel", Priority = Priority.High, Status = Status.Completed, Notes = " " },
                new HelpDeskCalls { ProblemDescription = "Rat in office bathroom", DateReported = "1/15/21", PersonReported = "Pam Lasslo", Priority = Priority.Medium, Status = Status.InProg, Notes = " " },
                new HelpDeskCalls { ProblemDescription = "Coffee machine is dirty", DateReported = "1/11/21", PersonReported = "Rip Rundle", Priority = Priority.Low, Status = Status.NotStarted, Notes = " " },
                new HelpDeskCalls { ProblemDescription = "Elevator missing", DateReported = "2/14/21", PersonReported = "Debbie Stairs", Priority = Priority.High, Status = Status.Unresolved, Notes = " " },
                new HelpDeskCalls { ProblemDescription = "Ghost in paper shredder", DateReported = "2/20/21", PersonReported = "Randy's Ghost", Priority = Priority.Low, Status = Status.NotStarted, Notes = " " },
                new HelpDeskCalls { ProblemDescription = "Internet works too well", DateReported = "2/1/21", PersonReported = "Beef Slowmo", Priority = Priority.Medium, Status = Status.Completed, Notes = " " }
            };

            // use switch & foreach loop to give value to notes based on status enum.
            foreach (var report in calls)
            {
                switch (report.Status)
                {
                    case Status.NotStarted:
                        report.Notes = "Just Reported";
                        break;
                    case Status.InProg:
                        report.Notes = "Help Desk personnel on scene";
                        break;
                    case Status.Completed:
                        report.Notes = "Ticket is complete";
                        break;
                    case Status.Unresolved:
                        report.Notes = "Ongoing Investigation";
                        break;
                } // end switch 

                // test output for switch statement 
                //Console.WriteLine(report.ProblemDescription);
            } // end foreach 

            foreach (var reportPriority in calls)
            { 
                switch (reportPriority.Priority)
                {
                    case Priority.Low :
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.Write("LOW PRIORITY-The problem is on the back-burner");
                        break;
                    case Priority.Medium:
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write("MEDIUM PRIORITY-The problem is important");
                        break;
                    case Priority.High:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("HIGH PRIORITY-The problem is critical");
                        break;
                } // end switch 

                // reset color per iteration and print output 
                Console.ResetColor();
                Console.WriteLine("\nREPORT from EMPLOYEE: {0} ON {1}\n{2}\nSTATUS-{3}\n", reportPriority.PersonReported, reportPriority.DateReported, reportPriority.ProblemDescription, reportPriority.Notes);

            } // end foreach 

            // pause 
            Console.ReadLine();

        } // end main 
    } // end Program Class
    
    class HelpDeskCalls
    {
        public string ProblemDescription { get; set;  }
        public string DateReported { get; set; }
        public string PersonReported { get; set; }
        public string Notes { get; set; }
        public Status Status { get; set; }
        public Priority Priority { get; set; }
    } // end HelpDeskCalls Class 

    enum Status
    {
        NotStarted, 
        InProg, 
        Completed, 
        Unresolved
    } // end enum Status 

    enum Priority
    {
        Low,
        Medium,
        High
    } // end enum Priority 
} // end namespace 
