﻿/**
 * Sean Armbruster 
 * Week 5 Homework: LINQ and LINQ Methods 
 * 
 * this program will use a variety of LINQ Query or Linq Methods to perfrom and display the results prompted.
 * 
 **/
using System;
using System.Collections.Generic;
using System.Linq;

namespace LINQ_BookList
{
    class LinqBookList
    {
        static void Main(string[] args)
        {
            List<Books> myBooks = new List<Books>()
            {
                new Books() {ISBN = "1234-45-34-3939", Title = "The Long Road", Publisher = "New York", Price = 25.00, Copyright = 2016},
                new Books() {ISBN = "988-65-34-9012", Title = "The Warrior", Publisher = "McGraw", Price = 55.00, Copyright = 2013},
                new Books() {ISBN = "8712-45-84-2539", Title = "Yesterday", Publisher = "New York", Price = 67.00, Copyright = 2013},
                new Books() {ISBN = "1234-78-99-3478", Title = "Programming Essentials", Publisher = "Dalton", Price = 35.00, Copyright = 2015},
                new Books() {ISBN = "8356-89-33-3251", Title = "Hello World", Publisher = "Chicago Press", Price = 115.00, Copyright = 2016},
            };

            // 1: Display ISBN, Title, Publisher for all books where publisher is New York
            var nyBooks = from books in myBooks
                          where books.Publisher == "New York"
                          select books;

            Console.WriteLine("1: Books where publisher is from New York: ");

            foreach (var book in nyBooks)   // show results 
            {
                Console.WriteLine("ISBN: {0}, Title: {1}, Publisher: {2}", book.ISBN, book.Title, book.Publisher);
            }

            Console.WriteLine("_____________________________________");     //divider 

            // 2: Display all fields for all books in descending order by Copyright 

            var descBooks = from book in myBooks
                            orderby book.Copyright descending
                            select book;

            Console.WriteLine("2: All books in descending order by copyright: ");

            foreach (var book in descBooks)      // Show Results 
            {
                Console.WriteLine("Copyright: {0}, ISBN: {1}, Title: {2}, Publisher: {3}, Price: {4:C}",
                                  book.Copyright,
                                  book.ISBN,
                                  book.Title,
                                  book.Publisher,
                                  book.Price);
            }

            Console.WriteLine("_____________________________________");         // divider 

            // 3: Display all fields for all books in descending order by Copyright where Publisher is New York

            var descBooksCopyNY = from book in myBooks
                                  orderby book.Copyright descending
                                  where book.Publisher == "New York"
                                  select book;

            Console.WriteLine("3: Books in descending order by copyright where publisher is New York: ");

            foreach (var book in descBooksCopyNY)       // Show Results 
            {
                Console.WriteLine("Copyright: {0}, ISBN: {1}, Title: {2}, Publisher: {3}, Price: {4:C}",
                                  book.Copyright,
                                  book.ISBN,
                                  book.Title,
                                  book.Publisher,
                                  book.Price);
            }

            Console.WriteLine("_____________________________________");      // divider 

            // 4: Display ISBN, Title for all books with the copyright greater than 2015

            var booksGreaterThan = from book in myBooks
                                   where book.Copyright > 2015
                                   select new { book.ISBN, book.Title };

            Console.WriteLine("4: Book ISBN and Title's with a copyright greater than 2015:");

            foreach (var book in booksGreaterThan)      // Show Results 
            {
                Console.WriteLine("ISBN: {0}, Title: {1}", book.ISBN, book.Title);
            }

            Console.WriteLine("_____________________________________");      // divider 

            // 5: Order the list in descending order by title and display the ISBN, Title of the first book in the list

            var bookDescTitle = myBooks.OrderByDescending(p => p.Title).First();

            Console.WriteLine("5: First book in the descending list according to titles: ");

            Console.WriteLine("ISBN: {0}, Title: {1}", bookDescTitle.ISBN, bookDescTitle.Title);    // Show Results 

            Console.WriteLine("_____________________________________");      // divider 

            // 6: Use LINQ to calculate the sum of the price for all books and display average cost 

            var avgPrice = myBooks.Average(p => p.Price);

            Console.WriteLine("6: The Average price of the books in the list is: {0:C}", avgPrice);

            Console.WriteLine("_____________________________________");      // divider 

            // 7: Use LINQ to calculate a 3% markup of the price for each book and display the title and markup price

            var updatePrice = myBooks.Where(p => p.Price > 0).Select(p => { p.Price = (p.Price * 0.03) + p.Price; return p; }).ToList();

            Console.WriteLine("7: The updated price of the books are: ");
            foreach (var book in updatePrice)
            {
                Console.WriteLine("{0} {1:C}", book.Title, book.Price);
            }

            // pause 
            Console.ReadLine();
            
        } // end main 
    } // end class 

    class Books
    {
        public string ISBN { get; set; }
        public string Title { get; set; }
        public string Publisher { get; set; }
        public double Price { get; set; }
        public int Copyright { get; set; }
    } // end Books Class 




} // end namespace 
