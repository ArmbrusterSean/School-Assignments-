/*:
 ## App Exercise - Workout Functions
 
 >These exercises reinforce Swift concepts in the context of a fitness tracking app.
 
 A `RunningWorkout` struct has been created for you below. Add a method on `RunningWorkout` called `postWorkoutStats` that prints out the details of the run. Then create an instance of `RunningWorkout` and call `postWorkoutStats()`.
 */
// This code creates a function within the RunningWorkout struct that prints the results from the instance variable values. The function is called aftetr the initialization of the instance variable and will print the values.
struct RunningWorkout {
    var distance: Double
    var time: Double
    var elevation: Double
    
    func postWorkoutStats() {
        print("Your Post Workout Stats\nDistance: \(distance)\nTime: \(time)\nElevation: \(elevation)")
    }
}

var workOut = RunningWorkout(distance: 11.00, time: 9.00, elevation: 5.00)

// call the postWorkoutStats() funciton
workOut.postWorkoutStats()
/*:
 A `Steps` struct has been created for you below, representing the day's step-tracking data. It has the goal number of steps for the day and the number of steps taken so far. Create a method on `Steps` called `takeStep` that increments the value of `steps` by one. Then create an instance of `Steps` and call `takeStep()`. Print the value of the instance's `steps` property before and after the method call.
 */
// this code creates a mutating method within the Steps struct that increments the step value by 1. The function is called after the initialization variable and when the step reference is printed, it will be incremented by 1.
struct Steps {
    var steps: Int
    var goal: Int
    
    mutating func takeStep() {
        steps += 1
    }
}

var mySteps = Steps(steps: 200, goal: 20000)

// call the takeStep function
mySteps.takeStep()

print(mySteps.steps)
//: [Previous](@previous)  |  page 6 of 10  |  [Next: Exercise - Computed Properties and Property Observers](@next)
