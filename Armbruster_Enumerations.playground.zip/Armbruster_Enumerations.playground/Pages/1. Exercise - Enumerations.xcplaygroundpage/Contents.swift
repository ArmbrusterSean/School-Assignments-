/*:
 ## Exercise - Enumerations
 
 Define a `Suit` enum with four possible cases: `clubs`, `spades`, `diamonds`, and `hearts`.
 */
/**
 Sean Armbruster
 4/17/2021
 
 This assignment is about Enumerations and their uses
 */

// define a Suit enum with four possible cases
enum Suit {
    case clubs, spades, diamonds, hearts
}
/*:
 Imagine you are being shown a card trick and have to draw a card and remember the suit. Create a variable instance of `Suit` called `cardInHand` and assign it to the `hearts` case. Print out the instance.
 */
// this variable holds the value of the hearts case in the Suit enum
var cardInHand: Suit = .hearts
print(cardInHand)

/*:
 Now imagine you have to put back the card you drew and draw a different card. Update the variable to be a spade instead of a heart.
 */
// updating the cardInHand variable to hold the .spades case in the Suit enum
cardInHand = .spades

/*:
 Imagine you are writing an app that will display a fun fortune (i.e. something like "You will soon find what you seek.") based on cards drawn. Write a function called `getFortune(cardSuit:)` that takes a parameter of type `Suit`. Inside the body of the function, write a switch statement based on the value of `cardSuit`. Print a different fortune for each `Suit` value. Call the function a few times, passing in different values for `cardSuit` each time.
 */
// this function contains a switch statement that assigns value to each enum case.
func getFortune(_ cardSuit: Suit) {
    switch cardSuit {
    case .clubs:
        print("You will eat a loaf of bread.")
    case .spades:
        print("You are not out of coffe yet.")
    case .diamonds:
        print("Your back wont hurt tomorrow.")
    case .hearts:
        print("You will find a dollar in a jacket, maybe.")
    }
}

// call the getFortune() function
getFortune(.spades)
getFortune(.hearts)
/*:
 Create a `Card` struct below. It should have two properties, one for `suit` of type `Suit` and another for `value` of type `Int`.
 */
// this struct has two proterties, one for the Suit struct and one for a value: Int
struct Card {
    var suit: Suit
    var value: Value    // changed to Value
}

/*:
 How many values can playing cards have? How many values can `Int` be? It would be safer to have an enum for the card's value as well. Inside the struct above, create an enum for `Value`. It should have cases for `ace`, `two`, `three`, `four`, `five`, `six`, `seven`, `eight`, `nine`, `ten`, `jack`, `queen`, `king`. Change the type of `value` from `Int` to `Value`. Initialize two `Card` objects and print a statement for each that details the card's value and suit.
 */
// define value as an enum that holds the possible card selections in a Suit.
enum Value {
    case ace, two, three, four, five, six, seven, eight, nine, ten, jack, queen, king
}

// initialize two card objects
let firstDraw = Card(suit: .hearts, value: .ten)
let secondDraw = Card(suit: .spades, value: .seven)

// print the contents of the card's value and suit
print("\(firstDraw.value) of \(firstDraw.suit)")
print("\(secondDraw.value) of \(secondDraw.suit)")
//: page 1 of 2  |  [Next: App Exercise - Swimming Workouts](@next)
