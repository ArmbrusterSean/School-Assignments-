/**
* Sean Armbruster 
* CSC 134 
* 
* Ch 15 - p985-986 : Ship, CruiseShip, and CargoShip Classes
**/


// include each Ship class 
#include "Ship.h"
#include "CruiseShip.h"
#include "CargoShip.h"

#include <iostream>
using namespace std;

int main()
{

	// use initialization list, dynamically allocating each pointer to objects with their default value
	Ship* ships[3] = {
		new Ship(),
		new CruiseShip(),
		new CargoShip()
	};

	// set name an year for Base Class 
	ships[0]->setName("EverGiven");
	ships[0]->setYear("1988");

	// use a pointer to the derived CruiseShip class using static casting 
	CruiseShip* csPoint = static_cast<CruiseShip*>(ships[1]);
	// set name, year, and max passengers for CruiseShip
	csPoint->setName("Ashley Gorman");
	csPoint->setYear("1956");
	csPoint->setMaxPassengers(1500);

	// use a pointer to the derived CargoShip class using static casting 
	CargoShip* cgPoint = static_cast<CargoShip*>(ships[2]);
	// set name, year, and max Tons for CargoShip
	cgPoint->setName("Shep");
	cgPoint->setYear("1977");
	cgPoint->setMaxTons(160000);

	// output 
	for (int i = 0; i < 3; i++) {
		ships[i]->print();
		cout << endl;
	}


	return 0;
}


