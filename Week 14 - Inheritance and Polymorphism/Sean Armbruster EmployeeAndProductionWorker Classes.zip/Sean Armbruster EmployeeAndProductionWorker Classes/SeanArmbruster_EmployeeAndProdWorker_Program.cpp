/**
* Sean Armbruster 
* CSC 134 
* 
* ch. 15 p.981 - Employee and Production Worker Classes 
* 
**/

#include <iomanip>
#include <iostream>
#include "ProductionWorker.h"   // including the ProductionWorker.h file which is derivitave of Employee.h
using namespace std;

int main()
{
	// create a ProductionWorker object 
	ProductionWorker worker;

	worker.setName("Sean Armbruster");
	worker.setNumber(1122);
	worker.setHireDate(16, 06, 2014);	// dd / mm / yyyy
	worker.setShift(1);					// 1 - day || 2 - night 
	worker.setPayRate(16.50);

	// format output 
	cout << fixed << setprecision(2);
	// output 
	cout << "Name: " << worker.getName() << endl;
	cout << "Employee number: " << worker.getNumber() << endl;
	cout << "Hire Date: " << worker.getHireDate() << endl;
	cout << "Working Shift: " << worker.getshift() << endl;
	cout << "Pay Rate: " << worker.getPayRate() << endl;

	return 0;
}

