/**
 
 
 Sean Armbruster
 5/1/2021
 This program displays the order of ViewController Lifecyce events as they happen 
 */

import UIKit

class MiddleViewController: UIViewController {

    // outlet for MiddleViewControl Label
    @IBOutlet var MiddleViewLabel: UILabel!
    
    // variable property to increment event 
    var eventNumber: Int = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addEvent(from: "viewDidLoad")
    }
    
    // this function increments the event number
    func addEvent(from: String) {
        if let existingText = MiddleViewLabel.text {
            MiddleViewLabel.text = "\(existingText)\nEvent Number \(eventNumber) was \(from)"
            eventNumber += 1
        }
    }
    // this sequence of funcitons shows the various stages of the viewcontroller when the button is pressed
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("viewWillAppear")
        addEvent(from: "viewWillAppear")
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("ViewDidAppear")
        addEvent(from: "viewDidAppear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("viewWillDisappear")
        addEvent(from: "viewWillDisappear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("ViewDidDisappear")
        addEvent(from: "viewDidDisappear")
    }
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
