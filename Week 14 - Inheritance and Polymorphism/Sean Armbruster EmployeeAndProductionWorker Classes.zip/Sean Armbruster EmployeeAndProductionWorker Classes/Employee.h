/**
* Sean Armbruster 
* CSC 134 
* Employee.h file - Base Class 
**/
#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
#include <iostream>

using namespace std; 

class Employee {
private: 
	string name;
	int number,
		hireDay,
		hireMonth,
		hireYear;
public:
	// default constructor 
	Employee() {
		name = "";
		number = 0;
		hireDay = 0;
		hireMonth = 0;
		hireYear = 0;
	}

	// overloaded constructor 
	Employee(string n, int num, int d, int m, int y) {
		name = n;
		number = num;
		// input validation: check for invalid date properties 
		if (d < 0 || d > 32 || m < 0) {
			cout << "Error!" << endl;
		}
		else {
			hireDay = d;
			hireMonth = m;
			hireYear = y;
		}
	}

	// getter functions 
	string getName() const { return name; }

	int getNumber() const { return number;  }

	string getHireDate() const {
		string dt = "";

		dt += to_string(hireDay) + "/" + to_string(hireMonth) + "/" + to_string(hireYear);

		return dt;
	}

	// setter functions 
	void setName(string n) { name = n; }

	void setNumber(int num) { number = num; }

	void setHireDate(int d, int m, int y) {
        // input validation: check for invalid date properties 
		if (d < 0 || d > 32 || m < 0 || m > 12 || y < 1900 || y > 2021) {
			cout << "Error!" << endl;
		}
		else {
			hireDay = d;
			hireMonth = m;
			hireYear = y;
		}
	}

};

#endif // !EMPLOYEE_H

