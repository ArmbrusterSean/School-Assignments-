/*:
 ## Exercise - Type Casting and Inspection
 
 Create a collection of type [Any], including a few doubles, integers, strings, and booleans within the collection. Print the contents of the collection.
 */

/**
 Sean Armbruster
 4/10/2021
 
 This assigment demonstrates the various uses for type casting
 */

// this code is a collection of type [Any] which contains various data types. The collection is then printed
let myCollection: [Any] = ["Hello", 0.7, true, "OMG", 55, 4.0, false]
print(myCollection)





/*:
 Loop through the collection. For each integer, print "The integer has a value of ", followed by the integer value. Repeat the steps for doubles, strings and booleans.
 */
// this code iterates through the collection od [Any] and prints each element as? it's data type
for element in myCollection {
    if let element = element as? Int {
        print("The integer has a value of \(element)")
    } else if let element = element as? Double {
        print("The double has a value of \(element)")
    } else if let element = element as? Bool {
        print("The bool has a value of \(element)")
    } else if let element = element as? String {
        print("The string has a value of \(element)")
    }
}
/*:
 Create a [String : Any] dictionary, where the values are a mixture of doubles, integers, strings, and booleans. Print the key/value pairs within the collection
 */
let myDictionary: [String: Any] = ["money" : 5.0, "bike" : 600, "status" : false, "okay" : "fine"]
print(myDictionary)
/*:
 Create a variable `total` of type `Double` set to 0. Then loop through the dictionary, and add the value of each integer and double to your variable's value. For each string value, add 1 to the total. For each boolean, add 2 to the total if the boolean is `true`, or subtract 3 if it's `false`. Print the value of `total`.
 */
// this code iterates through the dictionary [Any] elements and stores adds/subtracts the value from a double value.
var total: Double = 0
for element in myDictionary.values {
    if let element = element as? Int {
        total += Double(element)
    } else if let element = element as? Double {
        total += element
    } else if let element = element as? String {
        total += 1
    } else if let element = element as? Bool {
        if element == true {
            total += 2
        } else {
            total -= 3
        }
    }
}
print(total)
/*:
 Create a variable `total2` of type `Double` set to 0. Loop through the collection again, adding up all the integers and doubles. For each string that you come across during the loop, attempt to convert the string into a number, and add that value to the total. Ignore booleans. Print the total.
 */
// this code creates an empty double that stores the Integers and Doubles iterated through a dictionay's values. Each string encountered will attempt to convert to a double value as well and add it's value to the empty double 

var total2: Double = 0

for element in myDictionary.values {
    if let element = element as? Int {
        total2 += Double(element)
    } else if let element = element as? Double {
        total2 += element
    } else if let element = element as? String, let newString = Double(element) {
        total2 += newString
    }
}
print(total2)

//: page 1 of 2  |  [Next: App Exercise - Workout Types](@next)
