﻿/**
 * Sean Armbruster 
 * CSC 253 
 * Week 3
 * 
 * This program references the library mathLib and uses it's method getLargestInt to determine the largest int within the object reference.
 **/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mathLib; //Library created for this assignment 

namespace MyMathLibTester
{
    class Program
    {
        static void Main(string[] args)
        {
            // object reference to mathLib library 
            AccessMathLib mathLib = new AccessMathLib();

            // initialize mathLib objects 
            int biggestOutta2 = mathLib.getLargestInt(3, 5);
            int biggestOutta3 = mathLib.getLargestInt(3, 8, 7);
            int biggestOutta4 = mathLib.getLargestInt(3, 5, 7, 14);

            //output 
            Console.WriteLine(biggestOutta2);
            Console.WriteLine(biggestOutta3);
            Console.WriteLine(biggestOutta4);

            //pause 
            Console.ReadLine();

        } // end main 
    } // end class 
} // end namespace
