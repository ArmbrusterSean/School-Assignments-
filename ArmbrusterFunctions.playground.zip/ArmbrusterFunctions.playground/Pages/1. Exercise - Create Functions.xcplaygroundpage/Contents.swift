/*:
 ## Exercise - Create Functions
 
 Write a function called `introduceMyself` that prints a brief introduction of yourself. Call the function and observe the printout.
 */
/**
 * Sean Armbruster
 * 2 /28/ 2021
 * This assignment showcases the various ways to use Functions in swift.
 */

// this code contains a basic function that calls a print statement
func introduceMyself() {
    print("My name is Sean Armbruster and I am learning Swift!")
}

introduceMyself()

/*:
 Write a function called `magicEightBall` that generates a random number and then uses either a switch statement or if-else-if statements to print different responses based on the random number generated. `let randomNum = Int.random(in: 0...4)` will generate a random number from 0 to 4, after which you can print different phrases corresponding to the number generated. Call the function multiple times and observe the different printouts.
 */
// this code creates a function that generates a random number. The ramdom number results are then defined in a switch statment and the results will be printed accordingly
func magicEightBall() {
    
    let randomNum = Int.random(in: 1...5)
    
    switch randomNum {
    case 1:
        print("Hello, I'm number 1")
    case 2:
        print("Hello, I'm number 2")
    case 3:
        print("Hello, I'm number 3")
    case 4:
        print("Hello, I'm number 4")
    default:
        print("Hello, I'm number 5")
    }
}

magicEightBall()
magicEightBall()
magicEightBall()
magicEightBall()
//: page 1 of 6  |  [Next: App Exercise - A Functioning App](@next)
