﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherLibrary
{
    public class WeatherFunctions
    {
        public static double FahrenheitToCelsius(double fahr)
        {
            return (fahr - 32) * 5 / 9;
        } // end FahrenheitToCelsius

        public static double FahrenheitToKelvin(double fahr)
        {
            return (fahr - 32) * 5 / 9 + 273.15;
        } // FahrenheitToKelvin

        public static double CelsiusToFahrenheit(double cels)
        {
            return (cels * (9 / 5)) + 32;
        } // end CelsiusToFahrenheit

        public static double CelsiusToKelvin(double cels)
        {
            return cels + 273.15;
        } // CelsiusToKelvin 

        public static double HeatIndex(float fahr, float relHum)
        {
            return -42.379 + 2.04901523 * fahr + 10.14333127 * relHum - .22475541 *
                    fahr * relHum - .00683783 * fahr * fahr - .05481717 * relHum * relHum
                    + .00122874 * fahr * fahr * relHum + .00085282 * fahr * relHum * relHum
                    - .00000199 * fahr * fahr * relHum * relHum;
        } // end heatIndex 

        public static double WindChill(double wind, double fahr)
        {
            return 35.74 + (0.6215 * fahr) - 35.75 * (Math.Pow(wind, 0.16)) + (0.4275 * fahr) * Math.Pow(wind, 0.16);
        } // WindChill 

        public static double RelativeHumidity(double satVapor, double actualVapor)
        {
            return (satVapor / actualVapor) * 100;
        } // end RelativeHumidity 

        public static double MPHWindSpeed(double mph)
        {
            return mph * 0.868976;
        } // end MPHWindSpeed

        public static double KnotsWindSpeed(double knots)
        {
            return knots * 1.150779448;
        } // end KnotsWindSpeed
    } // end class 
}
