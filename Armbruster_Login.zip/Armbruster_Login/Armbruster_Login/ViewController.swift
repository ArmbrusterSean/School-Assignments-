/**
 Sean Armbruster
 4/22/2021
 This program demonstrates navigation controllers and segues as a login application
 */

import UIKit

class ViewController: UIViewController {

    // username text field outlet
    @IBOutlet var usernameTextField: UITextField!
    
    // forgot username button outlet
    @IBOutlet var forgotUsernameButton: UIButton!
    
    // forgot password button outlet
    @IBOutlet var forgotPasswordButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    // if forgot password button is pressed, show in title in landing page
    // else if forgot username button pressed, show in title in landing page
    // else show username in title in landing page when login is pressed
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let sender = sender as? UIButton else {return}
        
        if sender == forgotPasswordButton {
            segue.destination.navigationItem.title = "Forgot Password"
        } else if sender == forgotUsernameButton {
            segue.destination.navigationItem.title = "Forgot Username"
        } else {
            segue.destination.navigationItem.title = usernameTextField.text
        }
    }
    
    // action for forgot username button
    @IBAction func forgotUsernameButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "ShowInfo", sender: sender)
    }
    
    // action for forgotpassword button
    @IBAction func forgotPasswordButtonPressed(_ sender: Any) {
        performSegue(withIdentifier: "ShowInfo", sender: sender)
    }
    
}

