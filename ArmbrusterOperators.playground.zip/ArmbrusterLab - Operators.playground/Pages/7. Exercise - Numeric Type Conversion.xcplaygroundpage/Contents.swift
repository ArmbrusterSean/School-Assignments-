/*:
 ## Exercise - Numeric Type Conversion

 Create an integer constant `x` with a value of 10, and a double constant `y` with a value of 3.2. Create a constant `multipliedAsIntegers` equal to `x` times `y`. Does this compile? If not, fix it by converting your `Double` to an `Int` in the mathematical expression. Print the result.
 */
// This code will create a constant Int with value of 10 and double y with a value of 3.2. Another constant will store a value of the two previous variables multiplied.
let x: Int = 10
let y: Double = 3.2

var multipliedAsIntegers = x * Int(y)
print(multipliedAsIntegers)

// the original program would not run because an int cannot be multiplied with a double in Swift. Operators must involve similar data types unless they have been casted as fixed above ^^^^^

/*:
 Create a constant `multipliedAsDoubles` equal to `x` times `y`, but this time convert the `Int` to a `Double` in the expression. Print the result.
 */
// this code will caste an Int as a double in the previous example.
var multipliedAsDoubles = Double(x) * y
print(multipliedAsDoubles)

/*:
 Are the values of `multipliedAsIntegers` and `multipliedAsDoubles` different? Print a statement to the console explaining why.
 */
print("The values are different becuase the when converting a double to an int, the remainder is discarded no matter the value and the number takes the initial whole number form. This can cause problem when dealing with precise results.")

//: [Previous](@previous)  |  page 7 of 8  |  [Next: App Exercise - Converting Types](@next)
