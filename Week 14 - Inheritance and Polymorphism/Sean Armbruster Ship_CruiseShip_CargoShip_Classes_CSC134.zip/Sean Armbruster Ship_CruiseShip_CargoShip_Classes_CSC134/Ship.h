/**
* Sean Armbruster 
* This is the Ship.h file - the Base Class 
**/

#ifndef SHIP_H
#define SHIP_H

#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

class Ship {

protected:
	string name;
	string year;

public:
	//default constructor
	Ship() {
		name = "";
		year = "1950";
	}

	//overloaded constructor 
	Ship(string n, string y) {
		name = n;
		year = y;
	}

	// setters 
	void setName(string n) { name = n; }
	void setYear(string y) { year = y; }

	// virtual print function
	virtual void print() const {
		cout << "Name: " << name << endl;
		cout << "Build Year: " << year << endl;
	}
};

#endif // !SHIP_H
