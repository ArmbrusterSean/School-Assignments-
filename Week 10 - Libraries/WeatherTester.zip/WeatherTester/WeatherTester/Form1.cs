﻿/**
 * Sean Armbruster 
 * CSC 254 
 * 
 * This program is a weather calculator that uses a reference to the WeatherLibrary library
 **/  


using System;
using System.Windows.Forms;
using WeatherLibrary;

namespace WeatherTester
{
    public partial class WeatherCalculator : Form
    {
        public WeatherCalculator()
        {
            InitializeComponent();
        }

        /** 
         *  Weather Temperature Converter Buttons
         **/
        private void FahrToCel_Button_Click(object sender, EventArgs e)
        {
            if (FahrToCel_Input.Text == string.Empty)
            {
                MessageBox.Show("Please enter something in the textbox");
            }
            else
            {
                FahrToCel_Output.Text = WeatherFunctions.FahrenheitToCelsius(float.Parse(FahrToCel_Input.Text)).ToString("0.00");
            }

        }

        private void FahrToKel_Button_Click(object sender, EventArgs e)
        {
            if (FahrToKel_Input.Text == string.Empty)
            {
                MessageBox.Show("Please enter something in the textbox");
            }
            else
            {
                FahrToKel_Output.Text = WeatherFunctions.FahrenheitToKelvin(float.Parse(FahrToKel_Input.Text)).ToString("0.00");
            }
        }

        private void CelToFahr_Button_Click(object sender, EventArgs e)
        {
            if (CelToFahr_Input.Text == string.Empty)
            {
                MessageBox.Show("Please enter something in the textbox");
            }
            else
            {
                CelToFahr_Output.Text = WeatherFunctions.CelsiusToFahrenheit(float.Parse(CelToFahr_Input.Text)).ToString("0.00");
            }
        }

        private void CelToKel_Button_Click(object sender, EventArgs e)
        {
            if (CelToKel_Input.Text == string.Empty)
            {
                MessageBox.Show("Please enter something in the textbox");
            }
            else
            {
                CelToKel_Output.Text = WeatherFunctions.CelsiusToFahrenheit(float.Parse(CelToKel_Input.Text)).ToString("0.00");
            }
        }
        // end Weather Temp Converter Buttons 

        // Heat Index Button
        private void HeatIndex_Butoon_Click(object sender, EventArgs e)
        {
            if (HeatIndex_Input1.Text == string.Empty || HeatIndex_Input2.Text == string.Empty)
            {
                MessageBox.Show("Please enter something in the textbox");
            }
            else
            {
                HeatIndex_Output.Text = WeatherFunctions.HeatIndex(float.Parse(HeatIndex_Input1.Text), float.Parse(HeatIndex_Input2.Text)).ToString("0.00");
            }
        }


        // Wind Chill Button 
        private void WindChill_Button_Click(object sender, EventArgs e)
        {
            if (WindChill_Input1.Text == string.Empty || WindChill_Input2.Text == string.Empty)
            {
                MessageBox.Show("Please enter something in the textbox");
            }
            else
            {
                WindChill_Output.Text = WeatherFunctions.WindChill(float.Parse(WindChill_Input1.Text), float.Parse(WindChill_Input2.Text)).ToString("0.00");
            }
        }

        // Relatice humidity Button 
        private void RelHum_Button_Click(object sender, EventArgs e)
        {
            if (RelHum_Input1.Text == string.Empty || RelHum_Input2.Text == string.Empty)
            {
                MessageBox.Show("Please enter something in the textbox");
            }
            else
            {
                RelHum_Output.Text = WeatherFunctions.RelativeHumidity(float.Parse(RelHum_Input1.Text), float.Parse(RelHum_Input2.Text)).ToString("0.00");
            }
        }

        // Mph to Knots button 
        private void ConvertToKnots_Button_Click(object sender, EventArgs e)
        {
            if (MPH_Input.Text == string.Empty)
            {
                MessageBox.Show("Please enter something in the textbox");
            }
            else
            {
                Knots_Output.Text = WeatherFunctions.MPHWindSpeed(float.Parse(MPH_Input.Text)).ToString("0.00");
            }
        }

        private void ConvertToMPH_Button_Click(object sender, EventArgs e)
        {
            if (Knots_Input.Text == string.Empty)
            {
                MessageBox.Show("Please enter something in the textbox");
            }
            else
            {
                MPH_Output.Text = WeatherFunctions.KnotsWindSpeed(float.Parse(Knots_Input.Text)).ToString("0.00");
            }
        }

        // weather temp converter clear button 
        private void weatherTempClear_Click(object sender, EventArgs e)
        {
            FahrToCel_Input.Clear();
            FahrToKel_Input.Clear();

            CelToFahr_Input.Clear();
            CelToKel_Input.Clear();
        }

        // clear heat index 
        private void HeatIndexClear_Click(object sender, EventArgs e)
        {
            HeatIndex_Input1.Clear();
            HeatIndex_Input2.Clear();
        }

        // Wind Chill Clear 
        private void WindChillClear_Click(object sender, EventArgs e)
        {
            WindChill_Input1.Clear();
            WindChill_Input2.Clear();
        }

        // relative humidity clear 
        private void RelHumClear_Click(object sender, EventArgs e)
        {
            RelHum_Input1.Clear();
            RelHum_Input2.Clear();
        }

        // MPH and Knots clear 
        private void MPHKnotsClear_Click(object sender, EventArgs e)
        {
            MPH_Input.Clear();
            Knots_Input.Clear();
        }

        
    } // end partial Class 
} // end namespace 
