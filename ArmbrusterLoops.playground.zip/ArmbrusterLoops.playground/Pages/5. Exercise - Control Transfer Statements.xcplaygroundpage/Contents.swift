/*:
 ## Exercise - Control Transfer Statements
 
 Create a for-in loop that will loop through `alphabet`. Inside the loop, print every other letter by continuing to the next iteration if you are on a letter you do not wish to print. (Hint: You can use the `isMultiple(of:)` method on `Int` to only print even indexed characters).
 */
// this code uses control transfer to iterate through a string and print only the even index values.

// I could't get this code to work. I'm not sure exactly how to implement the isMultiple function

let alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
var evenNums = alphabet.count.isMultiple(of: 2)


for i in alphabet {
    if !evenNums{
        break
    }
    else {
        print(i)
        continue
    }
}

/*:
 Create a `[String: String]` dictionary where the keys are names of states and the values are their capitals. Include at least three key/value pairs in your collection, with one of them being your home state. Now loop through this dictionary again, printing out the keys and values in a sentence, but add an if statement that will check if the current iteration is your home state. If it is, print("I found my home!") and break out of the loop.
 */
// this code creates a dictionary of strings and iterates the values. If a specific value is landed on, the loop will break and print a statement 
var library = ["Florida": "Tallahassee", "North Carolina": "Raleigh", "Alabama": "Mongomery"]

for i in library {
    print("\(i.key)'s capitol is \(i.value)")
    
    if i.key == "Florida" {
        print("I found my home!")
        break
    }
    
}

//: [Previous](@previous)  |  page 5 of 6  |  [Next: App Exercise - Finding Movements](@next)
