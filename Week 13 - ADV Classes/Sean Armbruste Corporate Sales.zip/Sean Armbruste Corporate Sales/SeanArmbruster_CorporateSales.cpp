

#include <iostream>
#include <iomanip>
#include <string>
#include "DivSales.h"   // include DivSales Class

using namespace std;

int main()
{
    // array of 6 DivSales objects 
    DivSales division[6];

    // quarterly division variables 
    double q1,
           q2,
           q3,
           q4;

    // prompt for quarterly sales for each of the six divisions 
    for (int i = 0; i < 6; i++) {
        cout << "Enter quarterly sales for division " << i + 1 << endl;
        cout << "Quarter One: ";
        cin >> q1;
        cout << "Quarter Two: ";
        cin >> q2;
        cout << "Quarter Three: ";
        cin >> q3;
        cout << "Quarter Fout: ";
        cin >> q4;

        // set values to current object 
        division[i].setQuarterlySales(q1, q2, q3, q4);
    }

    // table skeleton
    cout << "\n--------------Quarterly Sales-------------\n";
    cout << "\t\tQ1\tQ2\tQ3\tQ4\n";
    cout << "-------------------------------------------\n";
    cout << fixed << setprecision(2);

    // loop for displaying current division 
    for (int i = 0; i < 6; i++) {
        cout << "Division " << i + 1;

        //use loop to display quarterly sales
        for (int j = 0; j < 4; j++) {
            cout << "\t$" << division[j].getQaurter(j);
        }
        cout << endl;
    }

    //get/display corporate total 
    cout << "\n Corporate total: $" << division[0].getCorporateTotal();

    return 0;
}

