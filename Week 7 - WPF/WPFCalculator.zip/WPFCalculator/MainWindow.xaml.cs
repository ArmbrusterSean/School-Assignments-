﻿
/**
 * Sean Armbruster 
 * CSC 253 
 *  WPf Calculator 
 **/

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFCalculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {



        public MainWindow()
        {
            InitializeComponent();
        }

        private void Num1_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += 1.ToString();
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += 2.ToString();
        }

        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += 3.ToString();
        }

        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += 4.ToString();
        }

        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += 5.ToString();
        }

        private void btn6_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += 6.ToString();
        }

        private void btn7_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += 7.ToString();
        }

        private void btn8_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += 8.ToString();
        }

        private void btn9_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += 9.ToString();
        }

        private void btn0_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += 0.ToString();
        }

        private void Multiply_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += "*";
        }

        private void Divide_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += "/";
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += "+";
        }

        private void Subtract_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Text += "-";
        }

        private void Equals_Click(object sender, RoutedEventArgs e)
        {
            double result = Convert.ToDouble(new DataTable().Compute(txtNumOut.Text, ""));
            txtNumOut.Text = result.ToString();
        }

        private void Clear1_Click(object sender, RoutedEventArgs e)
        {
            txtNumOut.Clear();
        }

        private void txtNumOut_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}