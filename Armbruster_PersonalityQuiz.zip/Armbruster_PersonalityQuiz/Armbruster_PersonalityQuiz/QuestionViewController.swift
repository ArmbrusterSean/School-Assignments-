//
//  QuestionViewController.swift
//  Armbruster_PersonalityQuiz
//
//  Created by Sean Armbruster on 5/8/21.
//

import UIKit

class QuestionViewController: UIViewController {
    
    //properties
    var questionIndex = 0
    var answersChosen: [Answer] = []

    // outlets
    
    //question label
    @IBOutlet var questionLabel: UILabel!
    
    //single stack
    @IBOutlet var singleStackView: UIStackView!
    @IBOutlet var singleStackButton1: UIButton!
    @IBOutlet var singleStackButton2: UIButton!
    @IBOutlet var singleStackButton3: UIButton!
    @IBOutlet var singleStackButon4: UIButton!
    
    
    // multiple stack
    @IBOutlet var multipleStackView: UIStackView!
    @IBOutlet var multipleStackLabel1: UILabel!
    @IBOutlet var multipleStackLabel2: UILabel!
    @IBOutlet var multipleStackLabel3: UILabel!
    @IBOutlet var multipleStackLabel4: UILabel!

    
    @IBOutlet var multiSwitch1: UISwitch!
    @IBOutlet var multiSwitch2: UISwitch!
    @IBOutlet var multiSwitch3: UISwitch!
    @IBOutlet var multiSwitch4: UISwitch!
    
    // range stack
    @IBOutlet var rangeStackView: UIStackView!
    @IBOutlet var rangeStackLabel1: UILabel!
    @IBOutlet var rangeStackLabel2: UILabel!
    @IBOutlet var rangeSlider: UISlider!
    
    
    
    @IBOutlet var progressBar: UIProgressView!
    
    // Questions
    var questions: [Question] = [
        Question(
            text: "What excersize do you like to do?",
            type: .single,
            answers: [
                Answer(text: "Climbing", type: .koala),
                Answer(text: "Swimming", type: .duck),
                Answer(text: "None", type: .gator),
                Answer(text: "Jumping", type: .frog)]),
        Question(
            text: "What Foods would you be willing to try?",
            type: .multiple,
            answers: [
                Answer(text: "Just greens please", type: .koala ),
                Answer(text: "Live Fishes", type: .duck),
                Answer(text: "Literally Anything", type: .gator),
                Answer(text: "Bugs", type: .frog)]),
        Question(
            text: "How social are you?",
            type: .ranged,
            answers: [
                Answer(text: "Chill", type: .koala),
                Answer(text: "If there's food", type: .duck),
                Answer(text: "I bite", type: .gator),
                Answer(text: "I'm clingy", type: .frog)])
        ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }
    
  
    // update function
    func updateUI() {
        singleStackView.isHidden = true
        multipleStackView.isHidden = true
        rangeStackView.isHidden = true
        
        let currentQuestion = questions[questionIndex]
        let currentAnswers = currentQuestion.answers
        let totalProgress = Float(questionIndex) / Float(questions.count)

        navigationItem.title = "Question #\(questionIndex + 1)"
        questionLabel.text = currentQuestion.text
        progressBar.setProgress(totalProgress, animated: true)
        
        switch currentQuestion.type {
        case .single:
            updateSingleStack(using: currentAnswers)
        case .multiple:
            updateMultipleStack(using: currentAnswers)
        case .ranged:
            updateRangedStack(using: currentAnswers)
        }
    }
    
    func updateSingleStack(using answers: [Answer]) {
        singleStackView.isHidden = false
        singleStackButton1.setTitle(answers[0].text, for: .normal)
        singleStackButton2.setTitle(answers[1].text, for: .normal)
        singleStackButton3.setTitle(answers[2].text, for: .normal)
        singleStackButon4.setTitle(answers[3].text, for: .normal)
    }
    
    func updateMultipleStack(using answers: [Answer]) {
        multipleStackView.isHidden = false
        multiSwitch1.isOn = false
        multiSwitch2.isOn = false
        multiSwitch3.isOn = false
        multiSwitch4.isOn = false
        multipleStackLabel1.text = answers[0].text
        multipleStackLabel2.text = answers[1].text
        multipleStackLabel3.text = answers[2].text
        multipleStackLabel4.text = answers[3].text
    }
    
    func updateRangedStack(using answers: [Answer]) {
        rangeStackView.isHidden = false
        rangeSlider.setValue(0.5, animated: false)
        rangeStackLabel1.text = answers.first?.text
        rangeStackLabel2.text = answers.last?.text
    }
    
    // single stack button function
    @IBAction func singleAnswersButtonPressed(_ sender: UIButton) {
        let currentAnswers = questions[questionIndex].answers
        
        switch sender {
        case singleStackButton1:
            answersChosen.append(currentAnswers[0])
        case singleStackButton2:
            answersChosen.append(currentAnswers[1])
        case singleStackButton3:
            answersChosen.append(currentAnswers[2])
        case singleStackButon4:
            answersChosen.append(currentAnswers[3])
        default:
            break
        }
        
        nextQuestion()
    }
    
    // multi stack button pressed
    @IBAction func multipleAnswersButtonPressed() {
        let currentAnswers = questions[questionIndex].answers
        
        if multiSwitch1.isOn {
            answersChosen.append(currentAnswers[0])
        }
        if multiSwitch2.isOn {
            answersChosen.append(currentAnswers[1])
        }
        if multiSwitch3.isOn {
            answersChosen.append(currentAnswers[2])
        }
        if multiSwitch4.isOn {
            answersChosen.append(currentAnswers[3])
        }
        nextQuestion()
    }
    
    // range stack button pressed
    @IBAction func rangedAnswerButtonPressed() {
        let currentAnswers = questions[questionIndex].answers
        
        let index = Int(round(rangeSlider.value * Float(currentAnswers.count - 1)))
        
        answersChosen.append(currentAnswers[index])
        
        nextQuestion()
    }
    
    // get next questions
    func nextQuestion() {
        questionIndex += 1
        
        if questionIndex < questions.count {
            updateUI()
        } else {
            performSegue(withIdentifier: "Results", sender: nil)
        }
    }
    
   @IBSegueAction func showResults(_ coder: NSCoder) -> ResultsViewController? {
        return ResultsViewController(coder: coder, responses: answersChosen)
    }
    
    
    
}

