/**
* Sean Armbruster 
* CSC 134 
* ProductionWorker.h file - inherits from Employee.h
**/

#ifndef PRODUCTIONWORKER_H
#define PRODUCTIONWORKER_H

#include <string>
#include "Employee.h"
using namespace std;

// the ProductionWorker class inherits from the Employee class 
class ProductionWorker : public Employee {
private:
	int shift;
	double payRate;
public:
	// default constructor - calls default constructor from Base Class 
	ProductionWorker() : Employee()
	{
		shift = 1;
		payRate = 0.0;
	}

	// overloaded constructor - calls overloaded construcotr form base class
	ProductionWorker(string n, int num, int d, int m, int y, int sh, double pr) : Employee(n, num, d, m, y)
	{
		// input validation for payRate (pr) and shift(sh)
		if ((sh != 1 && sh != 2) || pr < 0) {
			cout << "Error! Invalid amount for Pay Rate and/or Shift.";
		}
		else {
			shift = sh;
			payRate = pr;
		}
	}

	// getter functions 

	string getshift() const {
		// returns day or night in accordance with shift #
		if (shift == 1)
			return "Day";
		return "Night";
	}

	double getPayRate() const { return payRate; }

	// setter functions 

	void setShift(int sh) {
		// input validation for shift(sh)
		if (sh != 1 && sh != 2) {
			cout << "Error! Invalid Shift.";
		}
		else {
			shift = sh;
		}
	}

	void setPayRate(double pr) {
		if (pr < 0) {
			cout << "Invalid Pay Rol amount! " << endl;
		}
		else {
			payRate = pr;
		}
	}

};

#endif // !PRODUCTIONWORKER_H
