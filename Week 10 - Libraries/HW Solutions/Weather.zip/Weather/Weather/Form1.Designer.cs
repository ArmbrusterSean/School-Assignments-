﻿namespace Weather
{
    partial class frmWeather
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpTemperature = new System.Windows.Forms.GroupBox();
            this.txtTempValue = new System.Windows.Forms.TextBox();
            this.lblTempValue = new System.Windows.Forms.Label();
            this.btnTempConvert = new System.Windows.Forms.Button();
            this.cmbTempTo = new System.Windows.Forms.ComboBox();
            this.cmbTempFrom = new System.Windows.Forms.ComboBox();
            this.lblTempTo = new System.Windows.Forms.Label();
            this.lblTempFrom = new System.Windows.Forms.Label();
            this.grpHeatIndex = new System.Windows.Forms.GroupBox();
            this.lblHIAnswer = new System.Windows.Forms.Label();
            this.lblHIAnswerLabel = new System.Windows.Forms.Label();
            this.btnHICalculate = new System.Windows.Forms.Button();
            this.lblRelativeHumidityPercentSign = new System.Windows.Forms.Label();
            this.txtHIRelativeHumidity = new System.Windows.Forms.TextBox();
            this.lblFarenheitDegree = new System.Windows.Forms.Label();
            this.txtHIFarenheit = new System.Windows.Forms.TextBox();
            this.lblHIRelatieHumidity = new System.Windows.Forms.Label();
            this.lblHITemp = new System.Windows.Forms.Label();
            this.grpWindChill = new System.Windows.Forms.GroupBox();
            this.lblWindChillAnswer = new System.Windows.Forms.Label();
            this.lblWindChillLabel = new System.Windows.Forms.Label();
            this.btnWindChill = new System.Windows.Forms.Button();
            this.lblWCMPH = new System.Windows.Forms.Label();
            this.txtWCSpeed = new System.Windows.Forms.TextBox();
            this.lblWCDegree = new System.Windows.Forms.Label();
            this.txtWCFarenheit = new System.Windows.Forms.TextBox();
            this.lblWCSpeed = new System.Windows.Forms.Label();
            this.lblWCFarenheit = new System.Windows.Forms.Label();
            this.grpRelativeHumidity = new System.Windows.Forms.GroupBox();
            this.lblRHAnswer = new System.Windows.Forms.Label();
            this.lblRHLabel = new System.Windows.Forms.Label();
            this.btnRelativeHumidity = new System.Windows.Forms.Button();
            this.txtAVP = new System.Windows.Forms.TextBox();
            this.txtSVP = new System.Windows.Forms.TextBox();
            this.lblAVP = new System.Windows.Forms.Label();
            this.lblSVP = new System.Windows.Forms.Label();
            this.grpWindSpeed = new System.Windows.Forms.GroupBox();
            this.txtWindSpeedValue = new System.Windows.Forms.TextBox();
            this.lblWindSpeedValue = new System.Windows.Forms.Label();
            this.btnWindSpeed = new System.Windows.Forms.Button();
            this.cmbWindSpeedTo = new System.Windows.Forms.ComboBox();
            this.cmbWindSpeedFrom = new System.Windows.Forms.ComboBox();
            this.lblWindSpeedTo = new System.Windows.Forms.Label();
            this.lblWindSpeedFrom = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblTempAnswerLabel = new System.Windows.Forms.Label();
            this.lblTempAnswer = new System.Windows.Forms.Label();
            this.lblWSAnswerLabel = new System.Windows.Forms.Label();
            this.lblWindSpeedAnswer = new System.Windows.Forms.Label();
            this.grpTemperature.SuspendLayout();
            this.grpHeatIndex.SuspendLayout();
            this.grpWindChill.SuspendLayout();
            this.grpRelativeHumidity.SuspendLayout();
            this.grpWindSpeed.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpTemperature
            // 
            this.grpTemperature.Controls.Add(this.lblTempAnswerLabel);
            this.grpTemperature.Controls.Add(this.lblTempAnswer);
            this.grpTemperature.Controls.Add(this.txtTempValue);
            this.grpTemperature.Controls.Add(this.lblTempValue);
            this.grpTemperature.Controls.Add(this.btnTempConvert);
            this.grpTemperature.Controls.Add(this.cmbTempTo);
            this.grpTemperature.Controls.Add(this.cmbTempFrom);
            this.grpTemperature.Controls.Add(this.lblTempTo);
            this.grpTemperature.Controls.Add(this.lblTempFrom);
            this.grpTemperature.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpTemperature.ForeColor = System.Drawing.Color.Blue;
            this.grpTemperature.Location = new System.Drawing.Point(12, 23);
            this.grpTemperature.Name = "grpTemperature";
            this.grpTemperature.Size = new System.Drawing.Size(351, 261);
            this.grpTemperature.TabIndex = 0;
            this.grpTemperature.TabStop = false;
            this.grpTemperature.Text = "Temperature Conversions";
            // 
            // txtTempValue
            // 
            this.txtTempValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTempValue.ForeColor = System.Drawing.Color.Black;
            this.txtTempValue.Location = new System.Drawing.Point(29, 62);
            this.txtTempValue.Name = "txtTempValue";
            this.txtTempValue.Size = new System.Drawing.Size(120, 26);
            this.txtTempValue.TabIndex = 1;
            // 
            // lblTempValue
            // 
            this.lblTempValue.AutoSize = true;
            this.lblTempValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempValue.ForeColor = System.Drawing.Color.Black;
            this.lblTempValue.Location = new System.Drawing.Point(29, 31);
            this.lblTempValue.Name = "lblTempValue";
            this.lblTempValue.Size = new System.Drawing.Size(148, 20);
            this.lblTempValue.TabIndex = 0;
            this.lblTempValue.Text = "Value to Convert:";
            // 
            // btnTempConvert
            // 
            this.btnTempConvert.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTempConvert.ForeColor = System.Drawing.Color.Black;
            this.btnTempConvert.Location = new System.Drawing.Point(28, 170);
            this.btnTempConvert.Name = "btnTempConvert";
            this.btnTempConvert.Size = new System.Drawing.Size(90, 32);
            this.btnTempConvert.TabIndex = 6;
            this.btnTempConvert.Text = "&Convert";
            this.btnTempConvert.UseVisualStyleBackColor = true;
            this.btnTempConvert.Click += new System.EventHandler(this.btnTempConvert_Click);
            // 
            // cmbTempTo
            // 
            this.cmbTempTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTempTo.ForeColor = System.Drawing.Color.Black;
            this.cmbTempTo.FormattingEnabled = true;
            this.cmbTempTo.Items.AddRange(new object[] {
            "Farenheit",
            "Celsius",
            "Kelvin"});
            this.cmbTempTo.Location = new System.Drawing.Point(215, 126);
            this.cmbTempTo.Name = "cmbTempTo";
            this.cmbTempTo.Size = new System.Drawing.Size(121, 28);
            this.cmbTempTo.TabIndex = 5;
            // 
            // cmbTempFrom
            // 
            this.cmbTempFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTempFrom.ForeColor = System.Drawing.Color.Black;
            this.cmbTempFrom.FormattingEnabled = true;
            this.cmbTempFrom.Items.AddRange(new object[] {
            "Farenheit",
            "Celsius"});
            this.cmbTempFrom.Location = new System.Drawing.Point(28, 126);
            this.cmbTempFrom.Name = "cmbTempFrom";
            this.cmbTempFrom.Size = new System.Drawing.Size(121, 28);
            this.cmbTempFrom.TabIndex = 4;
            // 
            // lblTempTo
            // 
            this.lblTempTo.AutoSize = true;
            this.lblTempTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempTo.ForeColor = System.Drawing.Color.Black;
            this.lblTempTo.Location = new System.Drawing.Point(211, 102);
            this.lblTempTo.Name = "lblTempTo";
            this.lblTempTo.Size = new System.Drawing.Size(29, 20);
            this.lblTempTo.TabIndex = 3;
            this.lblTempTo.Text = "To";
            // 
            // lblTempFrom
            // 
            this.lblTempFrom.AutoSize = true;
            this.lblTempFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempFrom.ForeColor = System.Drawing.Color.Black;
            this.lblTempFrom.Location = new System.Drawing.Point(28, 102);
            this.lblTempFrom.Name = "lblTempFrom";
            this.lblTempFrom.Size = new System.Drawing.Size(50, 20);
            this.lblTempFrom.TabIndex = 2;
            this.lblTempFrom.Text = "From";
            // 
            // grpHeatIndex
            // 
            this.grpHeatIndex.Controls.Add(this.lblHIAnswer);
            this.grpHeatIndex.Controls.Add(this.lblHIAnswerLabel);
            this.grpHeatIndex.Controls.Add(this.btnHICalculate);
            this.grpHeatIndex.Controls.Add(this.lblRelativeHumidityPercentSign);
            this.grpHeatIndex.Controls.Add(this.txtHIRelativeHumidity);
            this.grpHeatIndex.Controls.Add(this.lblFarenheitDegree);
            this.grpHeatIndex.Controls.Add(this.txtHIFarenheit);
            this.grpHeatIndex.Controls.Add(this.lblHIRelatieHumidity);
            this.grpHeatIndex.Controls.Add(this.lblHITemp);
            this.grpHeatIndex.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpHeatIndex.ForeColor = System.Drawing.Color.Blue;
            this.grpHeatIndex.Location = new System.Drawing.Point(396, 23);
            this.grpHeatIndex.Name = "grpHeatIndex";
            this.grpHeatIndex.Size = new System.Drawing.Size(368, 209);
            this.grpHeatIndex.TabIndex = 1;
            this.grpHeatIndex.TabStop = false;
            this.grpHeatIndex.Text = "Heat Index";
            // 
            // lblHIAnswer
            // 
            this.lblHIAnswer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblHIAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHIAnswer.ForeColor = System.Drawing.Color.Black;
            this.lblHIAnswer.Location = new System.Drawing.Point(144, 170);
            this.lblHIAnswer.Name = "lblHIAnswer";
            this.lblHIAnswer.Size = new System.Drawing.Size(70, 32);
            this.lblHIAnswer.TabIndex = 8;
            // 
            // lblHIAnswerLabel
            // 
            this.lblHIAnswerLabel.AutoSize = true;
            this.lblHIAnswerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHIAnswerLabel.ForeColor = System.Drawing.Color.Black;
            this.lblHIAnswerLabel.Location = new System.Drawing.Point(26, 176);
            this.lblHIAnswerLabel.Name = "lblHIAnswerLabel";
            this.lblHIAnswerLabel.Size = new System.Drawing.Size(112, 20);
            this.lblHIAnswerLabel.TabIndex = 7;
            this.lblHIAnswerLabel.Text = "Heat Index =";
            // 
            // btnHICalculate
            // 
            this.btnHICalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHICalculate.ForeColor = System.Drawing.Color.Black;
            this.btnHICalculate.Location = new System.Drawing.Point(26, 122);
            this.btnHICalculate.Name = "btnHICalculate";
            this.btnHICalculate.Size = new System.Drawing.Size(107, 34);
            this.btnHICalculate.TabIndex = 6;
            this.btnHICalculate.Text = "C&alculate";
            this.btnHICalculate.UseVisualStyleBackColor = true;
            this.btnHICalculate.Click += new System.EventHandler(this.btnHICalculate_Click);
            // 
            // lblRelativeHumidityPercentSign
            // 
            this.lblRelativeHumidityPercentSign.AutoSize = true;
            this.lblRelativeHumidityPercentSign.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRelativeHumidityPercentSign.ForeColor = System.Drawing.Color.Black;
            this.lblRelativeHumidityPercentSign.Location = new System.Drawing.Point(299, 79);
            this.lblRelativeHumidityPercentSign.Name = "lblRelativeHumidityPercentSign";
            this.lblRelativeHumidityPercentSign.Size = new System.Drawing.Size(24, 20);
            this.lblRelativeHumidityPercentSign.TabIndex = 5;
            this.lblRelativeHumidityPercentSign.Text = "%";
            // 
            // txtHIRelativeHumidity
            // 
            this.txtHIRelativeHumidity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHIRelativeHumidity.ForeColor = System.Drawing.Color.Black;
            this.txtHIRelativeHumidity.Location = new System.Drawing.Point(193, 77);
            this.txtHIRelativeHumidity.Name = "txtHIRelativeHumidity";
            this.txtHIRelativeHumidity.Size = new System.Drawing.Size(100, 26);
            this.txtHIRelativeHumidity.TabIndex = 4;
            // 
            // lblFarenheitDegree
            // 
            this.lblFarenheitDegree.AutoSize = true;
            this.lblFarenheitDegree.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFarenheitDegree.ForeColor = System.Drawing.Color.Black;
            this.lblFarenheitDegree.Location = new System.Drawing.Point(135, 83);
            this.lblFarenheitDegree.Name = "lblFarenheitDegree";
            this.lblFarenheitDegree.Size = new System.Drawing.Size(26, 20);
            this.lblFarenheitDegree.TabIndex = 3;
            this.lblFarenheitDegree.Text = "°F";
            // 
            // txtHIFarenheit
            // 
            this.txtHIFarenheit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHIFarenheit.ForeColor = System.Drawing.Color.Black;
            this.txtHIFarenheit.Location = new System.Drawing.Point(29, 79);
            this.txtHIFarenheit.Name = "txtHIFarenheit";
            this.txtHIFarenheit.Size = new System.Drawing.Size(100, 26);
            this.txtHIFarenheit.TabIndex = 2;
            // 
            // lblHIRelatieHumidity
            // 
            this.lblHIRelatieHumidity.AutoSize = true;
            this.lblHIRelatieHumidity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHIRelatieHumidity.ForeColor = System.Drawing.Color.Black;
            this.lblHIRelatieHumidity.Location = new System.Drawing.Point(189, 44);
            this.lblHIRelatieHumidity.Name = "lblHIRelatieHumidity";
            this.lblHIRelatieHumidity.Size = new System.Drawing.Size(148, 20);
            this.lblHIRelatieHumidity.TabIndex = 1;
            this.lblHIRelatieHumidity.Text = "Relative Humidity";
            // 
            // lblHITemp
            // 
            this.lblHITemp.AutoSize = true;
            this.lblHITemp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHITemp.ForeColor = System.Drawing.Color.Black;
            this.lblHITemp.Location = new System.Drawing.Point(22, 44);
            this.lblHITemp.Name = "lblHITemp";
            this.lblHITemp.Size = new System.Drawing.Size(111, 20);
            this.lblHITemp.TabIndex = 0;
            this.lblHITemp.Text = "Temperature";
            // 
            // grpWindChill
            // 
            this.grpWindChill.Controls.Add(this.lblWindChillAnswer);
            this.grpWindChill.Controls.Add(this.lblWindChillLabel);
            this.grpWindChill.Controls.Add(this.btnWindChill);
            this.grpWindChill.Controls.Add(this.lblWCMPH);
            this.grpWindChill.Controls.Add(this.txtWCSpeed);
            this.grpWindChill.Controls.Add(this.lblWCDegree);
            this.grpWindChill.Controls.Add(this.txtWCFarenheit);
            this.grpWindChill.Controls.Add(this.lblWCSpeed);
            this.grpWindChill.Controls.Add(this.lblWCFarenheit);
            this.grpWindChill.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpWindChill.ForeColor = System.Drawing.Color.Blue;
            this.grpWindChill.Location = new System.Drawing.Point(12, 309);
            this.grpWindChill.Name = "grpWindChill";
            this.grpWindChill.Size = new System.Drawing.Size(351, 209);
            this.grpWindChill.TabIndex = 3;
            this.grpWindChill.TabStop = false;
            this.grpWindChill.Text = "Wind Chill";
            // 
            // lblWindChillAnswer
            // 
            this.lblWindChillAnswer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblWindChillAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWindChillAnswer.ForeColor = System.Drawing.Color.Black;
            this.lblWindChillAnswer.Location = new System.Drawing.Point(144, 165);
            this.lblWindChillAnswer.Name = "lblWindChillAnswer";
            this.lblWindChillAnswer.Size = new System.Drawing.Size(70, 32);
            this.lblWindChillAnswer.TabIndex = 8;
            // 
            // lblWindChillLabel
            // 
            this.lblWindChillLabel.AutoSize = true;
            this.lblWindChillLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWindChillLabel.ForeColor = System.Drawing.Color.Black;
            this.lblWindChillLabel.Location = new System.Drawing.Point(33, 170);
            this.lblWindChillLabel.Name = "lblWindChillLabel";
            this.lblWindChillLabel.Size = new System.Drawing.Size(103, 20);
            this.lblWindChillLabel.TabIndex = 7;
            this.lblWindChillLabel.Text = "Wind Chill =";
            // 
            // btnWindChill
            // 
            this.btnWindChill.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWindChill.ForeColor = System.Drawing.Color.Black;
            this.btnWindChill.Location = new System.Drawing.Point(28, 121);
            this.btnWindChill.Name = "btnWindChill";
            this.btnWindChill.Size = new System.Drawing.Size(107, 34);
            this.btnWindChill.TabIndex = 6;
            this.btnWindChill.Text = "Ca&lculate";
            this.btnWindChill.UseVisualStyleBackColor = true;
            this.btnWindChill.Click += new System.EventHandler(this.btnWindChill_Click);
            // 
            // lblWCMPH
            // 
            this.lblWCMPH.AutoSize = true;
            this.lblWCMPH.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWCMPH.ForeColor = System.Drawing.Color.Black;
            this.lblWCMPH.Location = new System.Drawing.Point(299, 79);
            this.lblWCMPH.Name = "lblWCMPH";
            this.lblWCMPH.Size = new System.Drawing.Size(43, 20);
            this.lblWCMPH.TabIndex = 5;
            this.lblWCMPH.Text = "mph";
            // 
            // txtWCSpeed
            // 
            this.txtWCSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWCSpeed.ForeColor = System.Drawing.Color.Black;
            this.txtWCSpeed.Location = new System.Drawing.Point(193, 77);
            this.txtWCSpeed.Name = "txtWCSpeed";
            this.txtWCSpeed.Size = new System.Drawing.Size(100, 26);
            this.txtWCSpeed.TabIndex = 4;
            // 
            // lblWCDegree
            // 
            this.lblWCDegree.AutoSize = true;
            this.lblWCDegree.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWCDegree.ForeColor = System.Drawing.Color.Black;
            this.lblWCDegree.Location = new System.Drawing.Point(135, 83);
            this.lblWCDegree.Name = "lblWCDegree";
            this.lblWCDegree.Size = new System.Drawing.Size(26, 20);
            this.lblWCDegree.TabIndex = 3;
            this.lblWCDegree.Text = "°F";
            // 
            // txtWCFarenheit
            // 
            this.txtWCFarenheit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWCFarenheit.ForeColor = System.Drawing.Color.Black;
            this.txtWCFarenheit.Location = new System.Drawing.Point(29, 79);
            this.txtWCFarenheit.Name = "txtWCFarenheit";
            this.txtWCFarenheit.Size = new System.Drawing.Size(100, 26);
            this.txtWCFarenheit.TabIndex = 2;
            // 
            // lblWCSpeed
            // 
            this.lblWCSpeed.AutoSize = true;
            this.lblWCSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWCSpeed.ForeColor = System.Drawing.Color.Black;
            this.lblWCSpeed.Location = new System.Drawing.Point(189, 44);
            this.lblWCSpeed.Name = "lblWCSpeed";
            this.lblWCSpeed.Size = new System.Drawing.Size(61, 20);
            this.lblWCSpeed.TabIndex = 1;
            this.lblWCSpeed.Text = "Speed";
            // 
            // lblWCFarenheit
            // 
            this.lblWCFarenheit.AutoSize = true;
            this.lblWCFarenheit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWCFarenheit.ForeColor = System.Drawing.Color.Black;
            this.lblWCFarenheit.Location = new System.Drawing.Point(22, 44);
            this.lblWCFarenheit.Name = "lblWCFarenheit";
            this.lblWCFarenheit.Size = new System.Drawing.Size(111, 20);
            this.lblWCFarenheit.TabIndex = 0;
            this.lblWCFarenheit.Text = "Temperature";
            // 
            // grpRelativeHumidity
            // 
            this.grpRelativeHumidity.Controls.Add(this.lblRHAnswer);
            this.grpRelativeHumidity.Controls.Add(this.lblRHLabel);
            this.grpRelativeHumidity.Controls.Add(this.btnRelativeHumidity);
            this.grpRelativeHumidity.Controls.Add(this.txtAVP);
            this.grpRelativeHumidity.Controls.Add(this.txtSVP);
            this.grpRelativeHumidity.Controls.Add(this.lblAVP);
            this.grpRelativeHumidity.Controls.Add(this.lblSVP);
            this.grpRelativeHumidity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpRelativeHumidity.ForeColor = System.Drawing.Color.Blue;
            this.grpRelativeHumidity.Location = new System.Drawing.Point(396, 245);
            this.grpRelativeHumidity.Name = "grpRelativeHumidity";
            this.grpRelativeHumidity.Size = new System.Drawing.Size(368, 273);
            this.grpRelativeHumidity.TabIndex = 4;
            this.grpRelativeHumidity.TabStop = false;
            this.grpRelativeHumidity.Text = "Relative Humidity";
            // 
            // lblRHAnswer
            // 
            this.lblRHAnswer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRHAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRHAnswer.ForeColor = System.Drawing.Color.Black;
            this.lblRHAnswer.Location = new System.Drawing.Point(214, 229);
            this.lblRHAnswer.Name = "lblRHAnswer";
            this.lblRHAnswer.Size = new System.Drawing.Size(70, 32);
            this.lblRHAnswer.TabIndex = 8;
            // 
            // lblRHLabel
            // 
            this.lblRHLabel.AutoSize = true;
            this.lblRHLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRHLabel.ForeColor = System.Drawing.Color.Black;
            this.lblRHLabel.Location = new System.Drawing.Point(31, 234);
            this.lblRHLabel.Name = "lblRHLabel";
            this.lblRHLabel.Size = new System.Drawing.Size(163, 20);
            this.lblRHLabel.TabIndex = 7;
            this.lblRHLabel.Text = "Relative Humidity =";
            // 
            // btnRelativeHumidity
            // 
            this.btnRelativeHumidity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRelativeHumidity.ForeColor = System.Drawing.Color.Black;
            this.btnRelativeHumidity.Location = new System.Drawing.Point(29, 185);
            this.btnRelativeHumidity.Name = "btnRelativeHumidity";
            this.btnRelativeHumidity.Size = new System.Drawing.Size(107, 34);
            this.btnRelativeHumidity.TabIndex = 6;
            this.btnRelativeHumidity.Text = "Calc&ulate";
            this.btnRelativeHumidity.UseVisualStyleBackColor = true;
            this.btnRelativeHumidity.Click += new System.EventHandler(this.btnRelativeHumidity_Click);
            // 
            // txtAVP
            // 
            this.txtAVP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAVP.ForeColor = System.Drawing.Color.Black;
            this.txtAVP.Location = new System.Drawing.Point(29, 148);
            this.txtAVP.Name = "txtAVP";
            this.txtAVP.Size = new System.Drawing.Size(100, 26);
            this.txtAVP.TabIndex = 4;
            // 
            // txtSVP
            // 
            this.txtSVP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSVP.ForeColor = System.Drawing.Color.Black;
            this.txtSVP.Location = new System.Drawing.Point(29, 74);
            this.txtSVP.Name = "txtSVP";
            this.txtSVP.Size = new System.Drawing.Size(100, 26);
            this.txtSVP.TabIndex = 2;
            // 
            // lblAVP
            // 
            this.lblAVP.AutoSize = true;
            this.lblAVP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAVP.ForeColor = System.Drawing.Color.Black;
            this.lblAVP.Location = new System.Drawing.Point(25, 118);
            this.lblAVP.Name = "lblAVP";
            this.lblAVP.Size = new System.Drawing.Size(189, 20);
            this.lblAVP.TabIndex = 1;
            this.lblAVP.Text = "Actual Vapor Pressure";
            // 
            // lblSVP
            // 
            this.lblSVP.AutoSize = true;
            this.lblSVP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSVP.ForeColor = System.Drawing.Color.Black;
            this.lblSVP.Location = new System.Drawing.Point(22, 44);
            this.lblSVP.Name = "lblSVP";
            this.lblSVP.Size = new System.Drawing.Size(218, 20);
            this.lblSVP.TabIndex = 0;
            this.lblSVP.Text = "Saturated Vapor Pressure";
            // 
            // grpWindSpeed
            // 
            this.grpWindSpeed.Controls.Add(this.lblWSAnswerLabel);
            this.grpWindSpeed.Controls.Add(this.lblWindSpeedAnswer);
            this.grpWindSpeed.Controls.Add(this.txtWindSpeedValue);
            this.grpWindSpeed.Controls.Add(this.lblWindSpeedValue);
            this.grpWindSpeed.Controls.Add(this.btnWindSpeed);
            this.grpWindSpeed.Controls.Add(this.cmbWindSpeedTo);
            this.grpWindSpeed.Controls.Add(this.cmbWindSpeedFrom);
            this.grpWindSpeed.Controls.Add(this.lblWindSpeedTo);
            this.grpWindSpeed.Controls.Add(this.lblWindSpeedFrom);
            this.grpWindSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpWindSpeed.ForeColor = System.Drawing.Color.Blue;
            this.grpWindSpeed.Location = new System.Drawing.Point(787, 23);
            this.grpWindSpeed.Name = "grpWindSpeed";
            this.grpWindSpeed.Size = new System.Drawing.Size(351, 261);
            this.grpWindSpeed.TabIndex = 2;
            this.grpWindSpeed.TabStop = false;
            this.grpWindSpeed.Text = "Wind Speed";
            // 
            // txtWindSpeedValue
            // 
            this.txtWindSpeedValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWindSpeedValue.ForeColor = System.Drawing.Color.Black;
            this.txtWindSpeedValue.Location = new System.Drawing.Point(29, 62);
            this.txtWindSpeedValue.Name = "txtWindSpeedValue";
            this.txtWindSpeedValue.Size = new System.Drawing.Size(120, 26);
            this.txtWindSpeedValue.TabIndex = 1;
            // 
            // lblWindSpeedValue
            // 
            this.lblWindSpeedValue.AutoSize = true;
            this.lblWindSpeedValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWindSpeedValue.ForeColor = System.Drawing.Color.Black;
            this.lblWindSpeedValue.Location = new System.Drawing.Point(29, 31);
            this.lblWindSpeedValue.Name = "lblWindSpeedValue";
            this.lblWindSpeedValue.Size = new System.Drawing.Size(148, 20);
            this.lblWindSpeedValue.TabIndex = 0;
            this.lblWindSpeedValue.Text = "Value to Convert:";
            // 
            // btnWindSpeed
            // 
            this.btnWindSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWindSpeed.ForeColor = System.Drawing.Color.Black;
            this.btnWindSpeed.Location = new System.Drawing.Point(32, 170);
            this.btnWindSpeed.Name = "btnWindSpeed";
            this.btnWindSpeed.Size = new System.Drawing.Size(90, 32);
            this.btnWindSpeed.TabIndex = 6;
            this.btnWindSpeed.Text = "C&onvert";
            this.btnWindSpeed.UseVisualStyleBackColor = true;
            this.btnWindSpeed.Click += new System.EventHandler(this.btnWindSpeed_Click);
            // 
            // cmbWindSpeedTo
            // 
            this.cmbWindSpeedTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWindSpeedTo.ForeColor = System.Drawing.Color.Black;
            this.cmbWindSpeedTo.FormattingEnabled = true;
            this.cmbWindSpeedTo.Items.AddRange(new object[] {
            "MPH",
            "Knots"});
            this.cmbWindSpeedTo.Location = new System.Drawing.Point(215, 126);
            this.cmbWindSpeedTo.Name = "cmbWindSpeedTo";
            this.cmbWindSpeedTo.Size = new System.Drawing.Size(121, 28);
            this.cmbWindSpeedTo.TabIndex = 5;
            // 
            // cmbWindSpeedFrom
            // 
            this.cmbWindSpeedFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWindSpeedFrom.ForeColor = System.Drawing.Color.Black;
            this.cmbWindSpeedFrom.FormattingEnabled = true;
            this.cmbWindSpeedFrom.Items.AddRange(new object[] {
            "MPH",
            "Knots"});
            this.cmbWindSpeedFrom.Location = new System.Drawing.Point(28, 126);
            this.cmbWindSpeedFrom.Name = "cmbWindSpeedFrom";
            this.cmbWindSpeedFrom.Size = new System.Drawing.Size(121, 28);
            this.cmbWindSpeedFrom.TabIndex = 4;
            // 
            // lblWindSpeedTo
            // 
            this.lblWindSpeedTo.AutoSize = true;
            this.lblWindSpeedTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWindSpeedTo.ForeColor = System.Drawing.Color.Black;
            this.lblWindSpeedTo.Location = new System.Drawing.Point(211, 102);
            this.lblWindSpeedTo.Name = "lblWindSpeedTo";
            this.lblWindSpeedTo.Size = new System.Drawing.Size(29, 20);
            this.lblWindSpeedTo.TabIndex = 3;
            this.lblWindSpeedTo.Text = "To";
            // 
            // lblWindSpeedFrom
            // 
            this.lblWindSpeedFrom.AutoSize = true;
            this.lblWindSpeedFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWindSpeedFrom.ForeColor = System.Drawing.Color.Black;
            this.lblWindSpeedFrom.Location = new System.Drawing.Point(28, 102);
            this.lblWindSpeedFrom.Name = "lblWindSpeedFrom";
            this.lblWindSpeedFrom.Size = new System.Drawing.Size(50, 20);
            this.lblWindSpeedFrom.TabIndex = 2;
            this.lblWindSpeedFrom.Text = "From";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(887, 327);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(125, 46);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear &Values";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(892, 391);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(120, 40);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblTempAnswerLabel
            // 
            this.lblTempAnswerLabel.AutoSize = true;
            this.lblTempAnswerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempAnswerLabel.ForeColor = System.Drawing.Color.Black;
            this.lblTempAnswerLabel.Location = new System.Drawing.Point(28, 216);
            this.lblTempAnswerLabel.Name = "lblTempAnswerLabel";
            this.lblTempAnswerLabel.Size = new System.Drawing.Size(83, 20);
            this.lblTempAnswerLabel.TabIndex = 7;
            this.lblTempAnswerLabel.Text = "Answer =";
            // 
            // lblTempAnswer
            // 
            this.lblTempAnswer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTempAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempAnswer.ForeColor = System.Drawing.Color.Black;
            this.lblTempAnswer.Location = new System.Drawing.Point(121, 210);
            this.lblTempAnswer.Name = "lblTempAnswer";
            this.lblTempAnswer.Size = new System.Drawing.Size(140, 32);
            this.lblTempAnswer.TabIndex = 8;
            // 
            // lblWSAnswerLabel
            // 
            this.lblWSAnswerLabel.AutoSize = true;
            this.lblWSAnswerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWSAnswerLabel.ForeColor = System.Drawing.Color.Black;
            this.lblWSAnswerLabel.Location = new System.Drawing.Point(30, 223);
            this.lblWSAnswerLabel.Name = "lblWSAnswerLabel";
            this.lblWSAnswerLabel.Size = new System.Drawing.Size(121, 20);
            this.lblWSAnswerLabel.TabIndex = 7;
            this.lblWSAnswerLabel.Text = "Wind Speed =";
            // 
            // lblWindSpeedAnswer
            // 
            this.lblWindSpeedAnswer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblWindSpeedAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWindSpeedAnswer.ForeColor = System.Drawing.Color.Black;
            this.lblWindSpeedAnswer.Location = new System.Drawing.Point(175, 215);
            this.lblWindSpeedAnswer.Name = "lblWindSpeedAnswer";
            this.lblWindSpeedAnswer.Size = new System.Drawing.Size(108, 32);
            this.lblWindSpeedAnswer.TabIndex = 8;
            // 
            // frmWeather
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(1150, 551);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.grpWindSpeed);
            this.Controls.Add(this.grpRelativeHumidity);
            this.Controls.Add(this.grpWindChill);
            this.Controls.Add(this.grpHeatIndex);
            this.Controls.Add(this.grpTemperature);
            this.Name = "frmWeather";
            this.Text = "Weather";
            this.grpTemperature.ResumeLayout(false);
            this.grpTemperature.PerformLayout();
            this.grpHeatIndex.ResumeLayout(false);
            this.grpHeatIndex.PerformLayout();
            this.grpWindChill.ResumeLayout(false);
            this.grpWindChill.PerformLayout();
            this.grpRelativeHumidity.ResumeLayout(false);
            this.grpRelativeHumidity.PerformLayout();
            this.grpWindSpeed.ResumeLayout(false);
            this.grpWindSpeed.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpTemperature;
        private System.Windows.Forms.ComboBox cmbTempTo;
        private System.Windows.Forms.ComboBox cmbTempFrom;
        private System.Windows.Forms.Label lblTempTo;
        private System.Windows.Forms.Label lblTempFrom;
        private System.Windows.Forms.Button btnTempConvert;
        private System.Windows.Forms.TextBox txtTempValue;
        private System.Windows.Forms.Label lblTempValue;
        private System.Windows.Forms.GroupBox grpHeatIndex;
        private System.Windows.Forms.Label lblRelativeHumidityPercentSign;
        private System.Windows.Forms.TextBox txtHIRelativeHumidity;
        private System.Windows.Forms.Label lblFarenheitDegree;
        private System.Windows.Forms.TextBox txtHIFarenheit;
        private System.Windows.Forms.Label lblHIRelatieHumidity;
        private System.Windows.Forms.Label lblHITemp;
        private System.Windows.Forms.Button btnHICalculate;
        private System.Windows.Forms.Label lblHIAnswer;
        private System.Windows.Forms.Label lblHIAnswerLabel;
        private System.Windows.Forms.GroupBox grpWindChill;
        private System.Windows.Forms.Label lblWindChillAnswer;
        private System.Windows.Forms.Label lblWindChillLabel;
        private System.Windows.Forms.Button btnWindChill;
        private System.Windows.Forms.Label lblWCMPH;
        private System.Windows.Forms.TextBox txtWCSpeed;
        private System.Windows.Forms.Label lblWCDegree;
        private System.Windows.Forms.TextBox txtWCFarenheit;
        private System.Windows.Forms.Label lblWCSpeed;
        private System.Windows.Forms.Label lblWCFarenheit;
        private System.Windows.Forms.GroupBox grpRelativeHumidity;
        private System.Windows.Forms.Label lblRHAnswer;
        private System.Windows.Forms.Label lblRHLabel;
        private System.Windows.Forms.Button btnRelativeHumidity;
        private System.Windows.Forms.TextBox txtAVP;
        private System.Windows.Forms.TextBox txtSVP;
        private System.Windows.Forms.Label lblAVP;
        private System.Windows.Forms.Label lblSVP;
        private System.Windows.Forms.GroupBox grpWindSpeed;
        private System.Windows.Forms.TextBox txtWindSpeedValue;
        private System.Windows.Forms.Label lblWindSpeedValue;
        private System.Windows.Forms.Button btnWindSpeed;
        private System.Windows.Forms.ComboBox cmbWindSpeedTo;
        private System.Windows.Forms.ComboBox cmbWindSpeedFrom;
        private System.Windows.Forms.Label lblWindSpeedTo;
        private System.Windows.Forms.Label lblWindSpeedFrom;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblTempAnswerLabel;
        private System.Windows.Forms.Label lblTempAnswer;
        private System.Windows.Forms.Label lblWSAnswerLabel;
        private System.Windows.Forms.Label lblWindSpeedAnswer;
    }
}

