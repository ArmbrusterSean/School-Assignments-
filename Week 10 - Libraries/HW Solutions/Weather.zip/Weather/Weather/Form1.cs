﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LibraryProject;

namespace Weather
{
    public partial class frmWeather : Form
    {
        // declare field variables
        double answer;
        double n;

        public frmWeather()
        {
            InitializeComponent();
        }
        
        // Temperature Conversions
        private void btnTempConvert_Click(object sender, EventArgs e)
        {
            try
            {
                // user input validation
                // check that values have been entered/selected for temperatures
                if (txtTempValue.Text == "" || cmbTempFrom.Text == "" || cmbTempTo.Text == "")
                {
                    MessageBox.Show("You must enter a numeric value and select from the two dropdowns.");
                }
                else
                {
                    // perform and display conversions from/to farenheit, celsius, kelvin based on input value
                    switch (cmbTempFrom.Text)
                    {
                        case "Farenheit":
                            if (cmbTempTo.Text == "Farenheit") // farenheit to farenheit
                            {
                                // test that value entered is numeric for same to same conversion                               
                                bool isNumeric = double.TryParse(lblTempAnswer.Text, out n);
                                if (isNumeric)
                                {
                                    lblTempAnswer.Text = txtTempValue.Text;
                                }
                                else
                                {
                                    MessageBox.Show("Value entered is not numeric.");
                                } // end IF statement
                            }
                            else if (cmbTempTo.Text == "Celsius") // farenheit to celsius
                            {
                                answer = LibraryProject.Weather.farenheitToCelsius(Double.Parse(txtTempValue.Text));
                                lblTempAnswer.Text = answer.ToString("n2");
                            }
                            else if (cmbTempTo.Text == "Kelvin") // farenheit to kelvin
                            {
                                answer = LibraryProject.Weather.farenheitToKelvin(Double.Parse(txtTempValue.Text));
                                lblTempAnswer.Text = answer.ToString("n2");
                            } // end if converting FROM Farenheit
                            break;
                        case "Celsius":
                            if (cmbTempTo.Text == "Farenheit") // celsius to farenheit
                            {
                                answer = LibraryProject.Weather.celsiusToFarenheit(Double.Parse(txtTempValue.Text));
                                lblTempAnswer.Text = answer.ToString();
                            }
                            else if (cmbTempTo.Text == "Celsius") // celsius to celsius
                            {
                                // test that value entered is numeric for same to same conversion                               
                                bool isNumeric = double.TryParse(lblTempAnswer.Text, out n);
                                if (isNumeric)
                                {
                                    lblTempAnswer.Text = txtTempValue.Text;
                                }
                                else
                                {
                                    MessageBox.Show("Value entered is not numeric.");
                                } // end IF statement
                                
                            }
                            else if (cmbTempTo.Text == "Kelvin") // celsius to kelvin
                            {
                                answer = LibraryProject.Weather.celsiusToKelvin(Double.Parse(txtTempValue.Text));
                                lblTempAnswer.Text = answer.ToString("n2");
                            } // end if converting FROM Celsius
                            break;
                    } // end switch statement
                } // end IF statement
            } // end try statement
            catch 
            {
                MessageBox.Show("Invalid value to convert was entered.");
            } // end catch statement
        } // end Convert button for Temperature Conversions

        // calculate heat index
        private void btnHICalculate_Click(object sender, EventArgs e)
        {
            try
            {
                // user input validation
                // check that farenheit and relative humidity values have been entered
                if (txtHIFarenheit.Text == "" || txtHIRelativeHumidity.Text == "")
                {
                    MessageBox.Show("You must enter numeric values for farenheit and relative humidity.");
                }
                else
                {
                    answer = LibraryProject.Weather.calculateHeatIndex(Double.Parse(txtHIFarenheit.Text), Double.Parse(txtHIRelativeHumidity.Text));
                    lblHIAnswer.Text = answer.ToString("n2");
                } // end IF statement
            } // end try statement
            catch
            {
                MessageBox.Show("Invalid values were entered for farenheit and relative humidity.");
            } // end catch statement
        } // end heat index

        // calculate wind chill
        private void btnWindChill_Click(object sender, EventArgs e)
        {
            try
            {
                // user input validation
                // check that farenheit and speed values have been entered
                if (txtWCFarenheit.Text == "" || txtWCSpeed.Text == "")
                {
                    MessageBox.Show("You must enter numeric values for farenheit and speed.");
                }
                else
                {
                    answer = LibraryProject.Weather.calculateWindChill(Double.Parse(txtWCFarenheit.Text), Double.Parse(txtWCSpeed.Text));
                    lblWindChillAnswer.Text = answer.ToString("n2");
                } // end IF statement
            } // end try statement
            catch
            {
                MessageBox.Show("Invalid values were entered for farenheit and speed.");
            } // end catch statement
        } // end wind chill

        // calculate relative humidity
        private void btnRelativeHumidity_Click(object sender, EventArgs e)
        {
            try
            {
                // user input validation
                // check that saturated vapor pressure and actual vapor pressure values have been entered
                if (txtSVP.Text == "" || txtAVP.Text == "")
                {
                    MessageBox.Show("You must enter numeric values for saturated vapor pressure and actual vapor pressure.");
                }
                else
                {
                    answer = LibraryProject.Weather.calculateRelativeHumidity(Double.Parse(txtSVP.Text), Double.Parse(txtAVP.Text));
                    lblRHAnswer.Text = answer.ToString("n2");
                } // end IF statement
            } // end try statement
            catch
            {
                MessageBox.Show("Invalid values were entered for saturated vapor pressure and actual vapor pressure.");
            } // end catch statement
        } // end relative humidity      

        // calculate wind speed
        private void btnWindSpeed_Click(object sender, EventArgs e)
        {
            try
            {
                // user input validation
                // check that a value has been entered and selections made in combo boxes
                if (txtWindSpeedValue.Text == "" || cmbWindSpeedFrom.Text == "" || cmbWindSpeedTo.Text == "")
                {
                    MessageBox.Show("You must enter a numeric value and select from the two dropdowns.");
                }
                else
                {
                    // calculate windspeed to/from MPH, Knots
                    switch (cmbWindSpeedFrom.Text)
                    {
                        case ("MPH"):
                            if (cmbWindSpeedTo.Text == "MPH") // from MPH to MPH
                            {
                                // test that value entered is numeric for same to same conversion                               
                                bool isNumeric = double.TryParse(lblTempAnswer.Text, out n);
                                if (isNumeric)
                                {
                                    lblWindSpeedAnswer.Text = txtWindSpeedValue.Text;
                                }
                                else
                                {
                                    MessageBox.Show("Value entered is not numeric.");
                                } // end IF statement
                            }
                            else if (cmbWindSpeedTo.Text == "Knots") // from MPH to Knots
                            {
                                answer = LibraryProject.Weather.calculateMPHToKnots(Double.Parse(txtWindSpeedValue.Text));
                                lblWindSpeedAnswer.Text = answer.ToString("n2");
                            }
                            break;
                        case ("Knots"):
                            if (cmbWindSpeedTo.Text == "MPH") // from Knots to MPH
                            {
                                answer = LibraryProject.Weather.calculateKnotsToMPH(Double.Parse(txtWindSpeedValue.Text));
                                lblWindSpeedAnswer.Text = answer.ToString("n2");
                            }
                            else if (cmbWindSpeedTo.Text == "Knots") // from Knots to Knots
                            {
                                // test that value entered is numeric for same to same conversion                               
                                bool isNumeric = double.TryParse(lblTempAnswer.Text, out n);
                                if (isNumeric)
                                {
                                    lblWindSpeedAnswer.Text = txtWindSpeedValue.Text;
                                }
                                else
                                {
                                    MessageBox.Show("Value entered is not numeric.");
                                } // end IF statement
                            }
                            break;
                    } // end switch statement
                } // end IF statement
            } // end try statement
            catch
            {
                MessageBox.Show("Invalid value to convert was entered.");
            } // end catch statement

        } // end wind speed

        // resets all values on the form
        private void btnClear_Click(object sender, EventArgs e)
        {
            // clears values for temperature conversions
            txtTempValue.Text = "";
            cmbTempFrom.SelectedIndex = -1;
            cmbTempTo.SelectedIndex = -1;
            lblTempAnswer.Text = "";

            // clears values for heat index group
            txtHIFarenheit.Text = "";
            txtHIRelativeHumidity.Text = "";
            lblHIAnswer.Text = "";

            // clears values for wind chill group
            txtWCFarenheit.Text = "";
            txtWCSpeed.Text = "";
            lblWindChillAnswer.Text = "";

            // clears values for relative humidity group
            txtSVP.Text = "";
            txtAVP.Text = "";
            lblRHAnswer.Text = "";

            // clears values for wind speed group
            txtWindSpeedValue.Text = "";
            cmbWindSpeedFrom.Text = "";
            cmbWindSpeedTo.Text = "";
            lblWindSpeedAnswer.Text = "";
        } // end clears values button

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); // closes form
        } // end Exit button
    } // end class
} // end namespace
