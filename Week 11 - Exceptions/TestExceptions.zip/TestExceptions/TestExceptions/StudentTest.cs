﻿/**
 * Sean Armbrsuter 
 * CSC 253 
 * 
 * 
 * Create your own Exception for two test:

1. Test if average is less 60. If so, display a message from the custom exception that says 
   "Average not up to NC State standards. Class is eliminated."
 
2. Test to see if there are any negative scores in the text file. 
   If so, display a message from the custom exception that says "Invalid data.
   Please check file." Hint: to test this, edit the text file and put a negative score in. 

If average is 60 or greater with no negative scores, write the average,
highest score and name, lowest score with name 
to an output.txt file (with exception handling when file is created).

 **/

using System;
using System.Collections.Generic;
using System.IO;   // for StreamReader 
using System.Linq;

namespace TestExceptions
{
    class StudentTest
    {
        static void Main(string[] args)
        {
            string lineFromFile;                                  // store every line of text file 
            List<int> studentGrade = new List<int>();            // store the studentGrade Values 
            List<string> studentName = new List<string>();      // store the studentName Values 

            // Read input.txt and throw exception if file is not found. 
            try
            {
                // Open the text file using a stream reader.
                using StreamReader sr = new StreamReader("C:/Users/ACER/Desktop/Spring Semester 2021/ADV C#/Week 11 - Exceptions/input.txt");
                // Read the stream as a string, and write the string to the console.
                //Console.WriteLine(sr.ReadToEnd());

                while ((lineFromFile = sr.ReadLine()) != null)
                {
                    string[] studentFile = lineFromFile.Split();    //tokenize the strings 

                    foreach (var i in studentFile)
                    {
                        // test whether string can be converted to double 
                        if (int.TryParse(i, out int result))
                            studentGrade.Add(result);
                        else
                            studentName.Add(i);

                    }   // end foreach
                } // end while 
            } // end try 
            catch (IOException e)
            {
                Console.WriteLine("The file could not be read\n");
                Console.WriteLine(e.Message);
            } // end catch 

            // fields for AVG, MAX, and MIN 
            double studentAvg = studentGrade.Average();
            int bestStudent = studentGrade.Max();
            int worstStudent = studentGrade.Min();
            string student;                         // hold the best/worst student name 
            int grade;                               // hold the best/worst student grade 

            Console.WriteLine("The best grade is: " + bestStudent);
            Console.WriteLine("The worst grade is: "+  worstStudent);

            // test for class average below 60 
            try
            {
                if (studentAvg < 60)
                    throw new BelowSixtyException();
            }
            catch (BelowSixtyException e)
            {
                e.LessThanSixty();
            }
            finally
            {
                Console.WriteLine("Class Average: " + studentAvg);
            }

            // test whether student score is positive or negative 
            foreach (var i in studentGrade)
            {
                try
                {
                    if (i < 0)
                        throw new NegativeScoreException();
                }
                catch (NegativeScoreException e)
                {
                    Console.WriteLine("There was a negative score! {0} ", i);
                    e.NegativeScore();
                }
            }// end forEach 

            // write to file 
            string fileName = @"Output.txt";
            try
            {
                using (StreamWriter writer = new StreamWriter(fileName))
                {
                    // if class average is over 60 and there are no negative grades, print the streamwriter 
                    if (studentAvg > 60)
                    {
                        // write the best and worst students 
                        for (int i = 0; i < studentGrade.Count; i++)
                        {
                            student = studentName[i];
                            grade = studentGrade[i];

                            if (studentGrade[i] == bestStudent)
                            {
                                writer.WriteLine("Best student is {0} with a grade of {1}\n", student, grade);
                            }
                            if (studentGrade[i] == worstStudent)
                            {
                                writer.WriteLine("Worst student is {0} with a grade of {1}\n", student, grade);
                            }
                        }
                        writer.Write("Class Average: {0}", studentAvg);
                    }
                }
            }
            catch (Exception exp)
            {
                Console.Write(exp.Message);
            }
            
            // pause 
            Console.ReadLine();

        } // end main 

        // This exception tests if average is less than 60 
        class BelowSixtyException : Exception
        {
            public void LessThanSixty()
            {
                Console.WriteLine("Average not up to NC State standards. Class is eliminated.");
            } // end LessThanSixty function 
        } // end BelowSixtyExcption Class 

        // this exception tests for negative ints 
        class NegativeScoreException : Exception
        {
            public void NegativeScore()
            {
                Console.WriteLine("Invalid data. Please check file.");
            } // end NegativeScore function 
        } // end NegativeScoreException Class 
    } // end Class
} // end namespace 
