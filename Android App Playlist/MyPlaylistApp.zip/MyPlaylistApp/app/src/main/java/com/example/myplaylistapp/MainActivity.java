package com.example.myplaylistapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final RadioButton sabbath = (RadioButton) findViewById(R.id.radSabbath);
        final RadioButton hailu = (RadioButton) findViewById(R.id.radHailu);
        final RadioButton sprinkles = (RadioButton) findViewById(R.id.radSprinkles);

        Button play = (Button) findViewById(R.id.btnPlay);

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sabbath.isChecked()){
                    Intent b = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=X7UZeHvMYZA"));
                    startActivity(b);
                } // end if
                else if(hailu.isChecked()) {
                    Intent b = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=kcuAFdBF-9I"));
                    startActivity(b);
                }// emd else if
                else { // sprinkles
                    Intent b = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=0CIHkJhgtpc"));
                    startActivity(b);
                }// end else
            } // end onClick
        });








    }// end onCreate
}// end class