/*:
 ## Exercise - Concatenation and Interpolation
 
 Create a `city` constant and assign it a string literal representing your home city. Then create a `state` constant and assign it a string literal representing your home state. Finally, create a `home` constant and use string concatenation to assign it a string representing your home city and state (i.e. Portland, Oregon). Print the value of `home`.
 */
// this code demonstrates concatination when printing two string literals
let city = "Carrboro"
let state = "North Carolina"
let home = city + ", " + state

print(home)

/*:
 Use the compound assignment operator (`+=`) to add `home` to `introduction` below. Print the value of `introduction`.
 */
// this code will use the += operator to modify the meaning of introduction
var introduction = "I live in"

introduction += " " + home
print(introduction)


/*:
 Declare a `name` constant and assign it your name as a string literal. Then declare an `age` constant and give it your current age as an `Int`. Then print the following phrase using string interpolation:
 
 - "My name is <INSERT NAME HERE> and after my next birthday I will be <INSERT AGE HERE> years old."
 
 Insert `name` where indicated, and insert a mathematical expression that evaluates to your current age plus one where indicated.
 */
// This code will create two constant variables and concatinate them using interpolation. The age value will increase by 1 using an expression within the calling of the variable in the print statement.
let name = "Sean Armbruster"
let age: Int = 30

print("My name is \(name) and after my next birthday I will be \(age + 1) years old.")
//: [Previous](@previous)  |  page 2 of 5  |  [Next: App Exercise - Notifications](@next)
