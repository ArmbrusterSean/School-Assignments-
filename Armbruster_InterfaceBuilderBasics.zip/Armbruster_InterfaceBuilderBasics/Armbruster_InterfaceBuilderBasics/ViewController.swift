//
//  ViewController.swift
//  Armbruster_InterfaceBuilderBasics
//
//  Created by Sean Armbruster on 2/13/21.
// Sean Armbruster
// 2/13/21
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var mainLabel: UILabel!
    
    @IBAction func changeTitle(_ sender: Any) {
        mainLabel.text = "This app rocks!"
    }
    
}

