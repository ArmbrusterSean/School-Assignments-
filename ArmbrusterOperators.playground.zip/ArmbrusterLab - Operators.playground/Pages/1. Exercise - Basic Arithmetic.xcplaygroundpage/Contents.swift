/*:
 ## Exercise - Basic Arithmetic
 
 You decide to build a shed and want to know beforehand the area of your yard that it will take up. Create two constants, `width` and `height`, with values of 10 and 20, respectively. Create an `area` constant that is the result of multiplying the two previous constants together, and print out the result.
 */
/**
 Sean Armbruster
 1/28/2021
 Purpose: This assignment will use various operators to solve and modify problems.
 */

// this code will create two constants representing width and height as well as a constant representing the area of the previously mentioned constants. The result will then be printed

let width = 10
let height = 20

let area = width * height

print(area)
/*:
 You decide that you'll divide your shed into two rooms. You want to know if dividing it equally will leave enough room for some of your larger storage items. Create a `roomArea` constant that is the result of dividing `area` in half. Print out the result.
 */
// this code will initiate a constant roomArea that will divide the previous area variable in half. The result will then be printed.

let roomArea = area / 2

print(roomArea)

/*:
 Create a `perimeter` constant whose value equals `width` plus `width` plus `height` plus `height`, then print out the result.
 */
// this code will create a perimeter constant that will represent width + width and height + height. The result will then be printed

let perimeter = (width + width) + (height + height)

print(perimeter)
/*:
 Print what you would expect the result of integer division of 10 divided by 3 to be. Create a constant, `integerDivisionResult` that is the result of 10 divided by 3, and print the value.
 */
// this code will create a constant integerDivisionResult that will divide 10 by 3 and print the reuslt.

let integerDivisionResult: Int = 10 / 3

print(integerDivisionResult) //  an int cannot carry a float point so the answer will be the integer 3 with the float point dropped.

/*:
 Now create two constants, `double10` and `double3`, set to 10 and 3, and declare their types as `Double` values. Declare a final constant `divisionResult` equal to the result of `double10` divided by `double3`. Print the value of `divisionResult`. How does this differ from the value when using integer division?
 */
// this code will create two initiated doubles and divide them. The result will be printed.

let double10: Double = 10
let double3: Double = 3

let divisionResult = double10 / double3

print(divisionResult) // the result is a double value with the remainder in tact.

/*:
 Given the value pi (3.1415927), create a `radius` constant with a value of 5.0, then calculate the diameter and circumference of the circle using the following equations, and print the results:
 
 *diameter = 2 * radius*
 
 *circumference = 2 * pi * radius.*
 */
// this code will find the circumference and diameter with the initialized constant raidus and pi. the result will then be printed

let pi = 3.1415927
let radius = 5.0

var diameter = radius * 2
var circumference = 2 * pi * radius

print(diameter)
print(circumference)
/*:
 Create an integer constant. Using the remainder operator, set its value to the remainder of 12 divided by 5.
 */
// this code will create an integer constant using % to calculate the remainder of 12/5.

let modulo = 12 % 5

//for posterity, I will print the result
print(modulo)

/*:
 Create two integer constants, `even` and `odd` and set them to any even integer and any odd integer, respectively. For each, print the remainder of dividing the value by 2. Looking at the results, how do you think you could use the remainder operator to determine if an integer is even or odd?
 */
// this code will create two int constants, one of even and one of odd value. They will then be printed % by 2.

let even: Int = 8
let odd: Int = 9

print(even % 2)
print(odd % 2)

// looking at the results, and even int % 2 will give a result of zero. An odd number % 2 will always produce an int larger than 0.

//: page 1 of 8  |  [Next: App Exercise - Fitness Calculations](@next)
