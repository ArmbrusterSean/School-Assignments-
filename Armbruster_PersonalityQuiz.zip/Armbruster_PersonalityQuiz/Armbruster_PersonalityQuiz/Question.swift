//
//  Question.swift
//  Armbruster_PersonalityQuiz
//
//  Created by Sean Armbruster on 5/9/21.
//

import Foundation

// this struct defines a question
struct Question {
    var text: String
    var type: ResponseType
    var answers: [Answer]
}

// this enum contains the pointers for the question type
enum ResponseType {
    case single, multiple, ranged
}

// struct for answers
struct Answer {
    var text: String
    var type: AnimalType
}

// this enum points to each animal type
enum AnimalType: String {
    case koala = "🐨", duck = "🐤", gator = "🐊", frog = "🐸"
    
    // each animal type as a switch case 
    var definition: String {
        switch self {
        case .koala:
            return "You love to hang out and eat greens with the pals. You defy odds and reach great heights."
        case .duck:
            return "You are quite talkative and people are always excited to see you. Might chase a fool for getting to close."
        case .gator:
            return "You are wise and slow to the roll but you aren't afraid to snap if the situation calls for it. You spend a lot of time dormant and contemplative."
        case .frog:
            return "You are attentive and reflective. You might find yourself in odd situations but people understand you are cool to have around. You love to sing in the night."
        }
    }
}
