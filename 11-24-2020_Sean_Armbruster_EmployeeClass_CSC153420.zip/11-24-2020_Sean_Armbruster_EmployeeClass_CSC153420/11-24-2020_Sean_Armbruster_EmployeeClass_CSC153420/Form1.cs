﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _11_24_2020_Sean_Armbruster_EmployeeClass_CSC153420
{
    public partial class CSC_153_420 : Form
    {
        class Employee
        {
            // declare fields
            private string _name;
            private int _ID;
            private string _dept;
            private string _position;

            // constructor
            public Employee(string name, int ID, string dept, string position)
            {
                _name = name;
                _ID = ID;
                _dept = dept;
                _position = position; 
            } // end consstructor 

            // name property
            public string EmpName
            {
                get { return _name; }
                set { _name = ""; }
            } // end EmpName

            public int EmpID
            {
                get { return _ID; }
                set { _ID = 0; }
            } // end EmpID

            public string EmpDept
            {
                get { return _dept; }
                set { _dept = ""; }
            } // end EmpDept

            public string EmpPos
            {
                get { return _position; }
                set { _position = ""; }
            } // end EmpPosition

        } // end Employee Class 


        public CSC_153_420()
        {
            InitializeComponent();
        } // end CSC_153_420



        private void button1_Click(object sender, EventArgs e)
        {
            Employee person1 = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");
            Employee person2 = new Employee("Mark Jones", 39119, "IT", "Programmer");
            Employee person3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");

            MessageBox.Show("Employee 1 : \n" +
                            "Name: " + person1.EmpName + "\n" +
                            "ID: " + person1.EmpID + "\n" +
                            "Department: " + person1.EmpDept + "\n" +
                            "Position: " + person1.EmpPos + "\n" + "\n" +
                            "Employee 2 : \n" +
                            "Name: " + person2.EmpName + "\n" +
                            "ID: " + person2.EmpID + "\n" +
                            "Department: " + person2.EmpDept + "\n" +
                            "Position: " + person2.EmpPos + "\n" + "\n" +
                            "Employee 3 : \n" +
                            "Name: " + person3.EmpName + "\n" +
                            "ID: " + person3.EmpID + "\n" +
                            "Department: " + person3.EmpDept + "\n" +
                            "Position: " + person3.EmpPos + "\n");


        }// end button1
    } // end parital Class 
} // end namespace
