﻿/**
 * Sean Armbruster 
 * CSC 253 
 * Week 4: 
 * This program uses the class Books and creates 5 object references
 * the references will then be added to a list as well as a dictionary(with IBSN as the key)
 * The program will then prompt for an IBSN # and output the value if correct.
 * The program will then ask for an IBSM # to remove value and output the new contents of the dictionary. 
 * 
 **/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListsAndDictionary
{
    class Books
    {
        public string ISBN { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Publisher { get; set; }
        public string Copywrite { get; set; }
        public string Date { get; set; }

    } // end Books class

    class BookMain
    {
        static void Main(string[] args)
        {
            // loop variables
            int i = 0;
            int j = 0;
            int y = 0;
            string searchDict;


            // 5 book object references 
            Books book1 = new Books()
            {
                ISBN = "12121212",
                Author = "Jorge Luis Borges",
                Title = "Labyrinths",
                Publisher = "New Directions",
                Copywrite = "ND07",
                Date = "1962"
            };

            Books book2 = new Books()
            {
                ISBN = "23232323",
                Author = "Phillip K Dick",
                Title = "Valis",
                Publisher = "Del Rey",
                Copywrite = "DR81",
                Date = "1981"
            };

            Books book3 = new Books()
            {
                ISBN = "34343434",
                Author = "Frank Herbert",
                Title = "Dune",
                Publisher = "Del Rey",
                Copywrite = "DR77",
                Date = "1965"
            };

            Books book4 = new Books()
            {
                ISBN = "45454545",
                Author = "Ursula Le Guinn",
                Title = "The Dispossessed",
                Publisher = "Harper",
                Copywrite = "H95",
                Date = "1973"
            };

            Books book5 = new Books()
            {
                ISBN = "56565656",
                Author = "Robert Aickman",
                Title = "Cold Hand in Mine",
                Publisher = "Folio",
                Copywrite = "F20",
                Date = "1975"
            };

            // create list & add object references to list 
            List<Books> bookList = new List<Books>();

            bookList.Add(book1);
            bookList.Add(book2);
            bookList.Add(book3);
            bookList.Add(book4);
            bookList.Add(book5);

            Console.WriteLine("--------Books in List---------");

            // output the contents of the list
            do
            {
                foreach (Books book in bookList)
                {
                    i++;
                    Console.WriteLine("Book # " + i + "\nIBSN: {0}\nAuthor: {1}\nTitle: {2}\nPublisher: {3}\nCopywrite: {4}\nDate: {5}\n"
                                      , book.ISBN, book.Author, book.Title, book.Publisher, book.Copywrite, book.Date);
                } // end foreach
            } while (i < bookList.Count());

            // pause 
            Console.ReadLine();


            // create a dictionary and store each book with the ISBN as the key 
            Dictionary<string, Books> bookDict = new Dictionary<string, Books>();

            bookDict.Add(book1.ISBN, book1);
            bookDict.Add(book2.ISBN, book2);
            bookDict.Add(book3.ISBN, book3);
            bookDict.Add(book4.ISBN, book4);
            bookDict.Add(book5.ISBN, book5);

            Console.WriteLine("---------------Books in Dictionary---------------------");

            // output the contents of the dictionary
            do
            {
                foreach (Books book in bookDict.Values)
                {
                    j++;
                    Console.WriteLine("Book # " + j + "\nAuthor: {0}\nTitle: {1}\nPublisher: {2}\nCopywrite: {3}\nDate: {4}\n"
                                      , book.Author, book.Title, book.Publisher, book.Copywrite, book.Date);
                } // end foreach
            } while (j < bookDict.Count());


            // pause, press enter 
            Console.ReadLine();
            Console.WriteLine("--------------------------------------------------------------\n");


            //this function will prompt for the IBSN key and display the author, title, publisher, copywrite, and date
            Console.WriteLine("Please Enter The IBSN of The Book: ");
            searchDict = Console.ReadLine();
            Key_Input(searchDict);

            void Key_Input(string s)
            {
                try
                {
                    Console.WriteLine("Author: {0}\nTitle: {1}\nPublisher: {2}\nCopywrite: {3}\nDate: {4}\n"
                                      ,bookDict[s].Author, bookDict[s].Title,
                                      bookDict[s].Publisher, bookDict[s].Copywrite,
                                      bookDict[s].Date);
                }// end try 
                catch (KeyNotFoundException)
                {
                    Console.WriteLine("Key Not Found");
                }// end catch 
            } // end Key_Input

            Console.WriteLine("--------------------------------------------------------------\n");

            Console.WriteLine("Please enter the IBSN of the book you wish to remove: ");
            searchDict = Console.ReadLine();
            Remove_Item(searchDict);

            // this function will prompt for the IBSN and remove it. The dicionary items will then output without the object entered. 
            void Remove_Item(string s)
            {
                try
                {
                    Console.WriteLine("You removed {0}, by {1} from the list.\n", bookDict[s].Title, bookDict[s].Author);
                    bookDict.Remove(s);
                    Console.WriteLine("Here is your new list:\n");

                    do
                    {
                        foreach (Books book in bookDict.Values)
                        {
                            y++;
                            Console.WriteLine("Book # " + y + "\nAuthor: {0}\nTitle: {1}\nPublisher: {2}\nCopywrite: {3}\nDate: {4}\n"
                                              , book.Author, book.Title, book.Publisher, book.Copywrite, book.Date);
                        } // end foreach
                    } while (j < bookDict.Count());

                }// end try 
                catch (KeyNotFoundException)
                {
                    Console.WriteLine("Key Not Found");
                }// end catch 
            }// end Remove_Item

            // pause 
            Console.ReadLine();

        } // end main 
    } // end BookMain Class
} // end Namesapce
