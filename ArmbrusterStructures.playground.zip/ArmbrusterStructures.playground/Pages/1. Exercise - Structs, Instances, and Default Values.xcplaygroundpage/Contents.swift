/*:
 ## Exercise - Structs, Instances, and Default Values
 
 Imagine you are creating an app that will monitor location. Create a `GPS` struct with two variable properties, `latitude` and `longitude`, both with default values of 0.0.
 */
/**
 * Sean Armbruster
 * 2/28/2021
 * This assignment is various examples of Structs, Instances, and Default Values
 */

// this code creates a struct with two variable properties initialized to 0.0
struct GPS {
    var latitude = Double.init()
    var longitude = Double.init()
}



/*:
 Create a variable instance of `GPS` called `somePlace`. It should be initialized without supplying any arguments. Print out the latitude and longitude of `somePlace`, which should be 0.0 for both.
 */
//this code creates an empty instance of the GPS struct and prints the default values of each property.
var somePlace = GPS()

print("Latitude: ", somePlace.latitude)
print("Longitude: ", somePlace.longitude)

/*:
 Change `somePlace`'s latitude to 51.514004, and the longitude to 0.125226, then print the updated values.
 */
// this code modifies the GPS instance somePlace
// this is the newly initialized values for the GPS struct properties

somePlace.latitude = 51.514004
somePlace.longitude = 0.125226

print("Latitude: ", somePlace.latitude)
print("Longitude: ", somePlace.longitude)

/*:
 Now imagine you are making a social app for sharing your favorite books. Create a `Book` struct with four variable properties: `title`, `author`, `pages`, and `price`. The default values for both `title` and `author` should be an empty string. `pages` should default to 0, and `price` should default to 0.0.
 */
// This code creates a struct Book and creates four properties initialized to their default var value

struct Book {
    var title = String.init()
    var author = String.init()
    var pages = Int.init()
    var price = Double.init()
}


/*:
 Create a variable instance of `Book` called `favoriteBook` without supplying any arguments. Print out the title of `favoriteBook`. Does it currently reflect the title of your favorite book? Probably not. Change all four properties of `favoriteBook` to reflect your favorite book. Then, using the properties of `favoriteBook`, print out facts about the book.
 */
//This code creates a variable instance of Book and first initializes it to the defualt values. This part is then commented out and a new initialization variable is created which holds values for each of the Book properties. The properties are then printed.

var favoriteBook = Book() // first initialization at default

print(favoriteBook.title) // print of first initialization

// new values
favoriteBook.title = "Dune"
favoriteBook.author = "Frank Herbert"
favoriteBook.pages = 500
favoriteBook.price = 7.00

print("My favorite book is \(favoriteBook.title) by \(favoriteBook.author). The book is ~\(favoriteBook.pages) pages and costs about $\(favoriteBook.price) new ")
//: page 1 of 10  |  [Next: App Exercise - Workout Tracking](@next)
