﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ_Example
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Car> myCars = new List<Car>()
            {
                new Car() {VIN = "A1", Make="BMW", Model="382i", Price=40000.00, Year=2016 },
                new Car() {VIN = "B2", Make="Toyota", Model="Camry", Price=30000.00, Year=2016 },
                new Car() {VIN = "C3", Make="BMW", Model="745li", Price=75000.00, Year=2015 },
                new Car() {VIN = "D4", Make="Chevy", Model="Camero", Price=35000.00, Year=2017 },
                new Car() {VIN = "E5", Make="BMW", Model="330i", Price=40000.00, Year=2017 },
            }; // end list 

            // LINQ Quert 
            var bmws = from car in myCars
                       where car.Make == "BMW"
                       && car.Year == 2017
                       select car;

            // show results 
            foreach (var car in bmws)
            {
                Console.WriteLine("{0} {1}", car.Make, car.Model);
            } // end foreach 


            /// divider 
            Console.WriteLine("------------------------");

            // order 
            var orderedCars = from car in myCars
                              orderby car.Year descending
                              select car;

            foreach (var car in orderedCars)
            {
                Console.WriteLine("{0} {1} {2}", car.Year, car.Make, car.Model);
            } // end foreach 

            /// divider 
            Console.WriteLine("------------------------");

            // couple of fields fromcars 
            var bmwsNew = from car in myCars
                          where car.Make == "BMW"
                          select new { car.Make, car.Model };

            // show results
            foreach (var car in bmwsNew)
            {
                Console.WriteLine("{0} {1}", car.Make, car.Model);
            } // end foreach 

            ////////////////////////////////////////////////////////
            /// /// 
            Console.WriteLine("------------------------");


            // LINQ Method 
            var bmws1 = myCars.Where(p => p.Make == "BMW" && p.Year == 2017);

            // show results 
            foreach (var car in bmws1)
            {
                Console.WriteLine("Method Result: {0} {1}", car.Make, car.Model);
            } // end foreach 

            Console.WriteLine("------------------------");

            //order 
            var orderedCars1 = myCars.OrderByDescending(p => p.Year);

            // show results 
            foreach (var car in orderedCars1)
            {
                Console.WriteLine("Method Result: {0} {1} {2}", car.Year, car.Make, car.Model);
            } // end foreach 

            Console.WriteLine("------------------------");

            // first 
            var firstBMW = myCars.First(p => p.Make == "BMW");

            // show results 
            Console.WriteLine("First BMW {0} {1} ", firstBMW.Make, firstBMW.Model);

            Console.WriteLine("------------------------");


            // change the above method with chaining 
            var firstBMW2 = myCars.OrderByDescending(p => p.Year).First(p => p.Make == "BMW");

            Console.WriteLine("Chaining results: {0} {1} {2} {3}", firstBMW2.Year, firstBMW2.Make, firstBMW2.Model, firstBMW2.Price);

            // newer than 2012
            if (myCars.TrueForAll(p => p.Year > 2021)) ;
            {
                Console.WriteLine("All cars are newer than 2012");
            }

            Console.WriteLine("------------------------");

            // sum of the prices 
            double sum = myCars.Sum(p => p.Price);

            Console.WriteLine("{0:C}", sum);



            // pause 
            Console.ReadLine();


        } // end main 
    }
} // end namespace 

class Car
{
    public String VIN { get; set; }
    public string Make { get; set; }
    public string Model { get; set; }
    public double Price { get; set; }
    public int Year { get; set; }

} // end Car class 
